-- =====================================================================
-- CHURROS DE PROPÓSITO — pré-cadastro inicial (rodar UMA vez, DEPOIS do 01-estrutura.sql)
-- Tudo aqui pode ser mudado depois pelo app (Administrador). Rodar de novo não duplica nada.
--
-- O que entra:
--   • Dados do restaurante (nome, WhatsApp, cidade, Instagram) e a faixa do topo do cardápio
--   • 4 formas de pagamento básicas (taxas zeradas — ajuste as do cartão no app)
--   • Categoria "Churros", 3 churros e 3 complementos
--
-- PREÇOS A CONFERIR COM O DONO:
--   Doce de Leite R$ 10,00 e Chocolate ao Leite R$ 12,00 (cartaz com o WhatsApp)
--   Misto R$ 14,00 e complementos R$ 2,00 cada  ← PALPITE, confirmar
--   O iFood não entra aqui: se for usar, cadastre a forma "iFood" no app com o acréscimo dela.
-- Fotos: suba pelo app (Produtos → editar → foto) usando a pasta fotos-cardapio.
-- =====================================================================
begin;

-- 1) Dados do restaurante + topo do cardápio
select public._cfg_gravar('RestauranteNome',     to_jsonb('Churros de Propósito'::text));
select public._cfg_gravar('RestauranteTelefone', to_jsonb('(16) 99714-6056'::text));
select public._cfg_gravar('RestauranteEndereco', to_jsonb('Jaboticabal - SP'::text));
select public._cfg_gravar('RestauranteRedes',    to_jsonb('Instagram: @churros_de_proposito'::text));
select public._cfg_gravar('CardapioKicker',      to_jsonb('FEITO NA HORA'::text));
select public._cfg_gravar('CardapioFrase',       to_jsonb('Mais que churros, é propósito.'::text));
-- Horário de funcionamento: preencher no app (Administrador → Dados do restaurante).

-- 2) Formas de pagamento
insert into public.formas_pagamento (nome, ativa, visivel_cardapio, permite_troco, ordem)
select v.nome, true, true, v.troco, v.ordem
from (values ('Dinheiro', true, 1), ('Pix', false, 2), ('Cartão de débito', false, 3), ('Cartão de crédito', false, 4)) as v(nome, troco, ordem)
where not exists (select 1 from public.formas_pagamento f where lower(f.nome) = lower(v.nome));

-- 3) Categoria
insert into public.categorias (nome, ativa, ordem)
select 'Churros', true, 1
where not exists (select 1 from public.categorias where lower(nome) = 'churros');

-- 4) Complementos (adicionais)
insert into public.adicionais (nome, preco, ativo, quantidade_descontar)
select v.nome, v.preco, true, 1
from (values ('Paçoca', 2.00), ('Leite em pó', 2.00), ('Granulado', 2.00)) as v(nome, preco)
where not exists (select 1 from public.adicionais a where lower(a.nome) = lower(v.nome));

-- 5) Produtos
insert into public.produtos (nome, descricao, categoria_id, ativo, destaque, ordem_cardapio)
select v.nome, v.descricao, (select id from public.categorias where lower(nome) = 'churros' limit 1), true, v.destaque, v.ordem
from (values
  ('Churros de Doce de Leite', 'Massa crocante e sequinha, passada no açúcar, com recheio generoso de doce de leite. Feito na hora.', true, 1),
  ('Churros de Chocolate ao Leite', 'Massa crocante e sequinha, passada no açúcar, com chocolate ao leite cremoso. Feito na hora.', false, 2),
  ('Churros Misto', 'Recheio de doce de leite e cobertura de chocolate ao leite. Feito na hora.', false, 3)
) as v(nome, descricao, destaque, ordem)
where not exists (select 1 from public.produtos p where lower(btrim(p.nome)) = lower(v.nome));

-- 6) Preço igual em todas as formas (o sistema usa preço único por produto; o que muda por forma é o acréscimo da forma)
insert into public.produto_precos (produto_id, forma_pagamento_id, preco, custo)
select p.id, f.id, v.preco, 0
from (values ('Churros de Doce de Leite', 10.00), ('Churros de Chocolate ao Leite', 12.00), ('Churros Misto', 14.00)) as v(nome, preco)
join public.produtos p on lower(btrim(p.nome)) = lower(v.nome)
cross join public.formas_pagamento f
where not exists (select 1 from public.produto_precos pp where pp.produto_id = p.id and pp.forma_pagamento_id = f.id);

-- 7) Os 3 complementos valem para os 3 churros
insert into public.produto_adicionais (produto_id, adicional_id)
select p.id, a.id
from public.produtos p
join public.adicionais a on lower(a.nome) in ('paçoca', 'leite em pó', 'granulado')
where lower(btrim(p.nome)) in ('churros de doce de leite', 'churros de chocolate ao leite', 'churros misto')
  and not exists (select 1 from public.produto_adicionais x where x.produto_id = p.id and x.adicional_id = a.id);

commit;

-- Conferência rápida (deve mostrar 3 churros × 4 formas = 12 preços e 9 ligações de complemento)
select (select count(*) from public.produtos) as produtos,
       (select count(*) from public.produto_precos) as precos,
       (select count(*) from public.produto_adicionais) as complementos_ligados;

-- Configuração inicial do backup automático (a tela de Backup só consegue salvar se estas linhas existirem)
insert into public.sistema (chave, valor) values
  ('BACKUP_AUTO_ATIVO', 'false'::jsonb), ('BACKUP_HORA', '4'::jsonb), ('BACKUP_FREQ', '"diario"'::jsonb)
on conflict (chave) do nothing;
