-- NOME_DO_RESTAURANTE — SQL só da bolinha (texto da Ajuda sobre as cores) · 2026-10-11
-- Supabase → SQL Editor → New query → cole → Run. Pode rodar mais de uma vez.

update ai_ajuda set
  palavras_chave = 'saúde sistema conexão servidores backup conferência vendas tarefas automáticas bolinha verde vermelha',
  passos = E'A "Saúde do sistema" fica dentro de "Conexão e servidores": toque na bolinha colorida do topo.\nLá aparecem os servidores e, logo abaixo, cada item: cópia para a planilha, backup (diário às 04:00), cópia no Drive, conferência diária de vendas, tarefas automáticas e Assistente.\nA própria bolinha do topo muda de cor: verde = tudo certo, amarela = atenção, rosa = precisa de cuidado (se a conexão cair, ela fica vermelha ou laranja). Amarelo pede atenção; vermelho pede ação (ex.: backup com mais de 48 h ou vendas diferentes entre Supabase e planilha).\nDesenvolvedor: o botão "Simular queda (treino)" fica em "Conexão e servidores" e finge a queda só neste aparelho. "Encerrar simulação" volta ao normal.',
  comuns = 'Só Admin e Desenvolvedor veem a Saúde do sistema.'
where slug = 'man-admin-97-saude-sistema';
