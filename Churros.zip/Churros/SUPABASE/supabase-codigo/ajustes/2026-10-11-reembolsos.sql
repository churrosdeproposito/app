-- Reembolsos de vendas canceladas · 2026-10-11 · seguro para rodar de novo (menos a policy: se já existir, apague a linha "create policy")
create table if not exists public.reembolsos (
  id uuid primary key default gen_random_uuid(),
  venda_id uuid not null unique references public.vendas(id),
  valor numeric(12,2) not null check (valor >= 0),
  forma_pagamento text not null default '',
  motivo text not null default '',
  cancelado_por uuid,
  criado_em timestamptz not null default now(),
  status text not null default 'Pendente' check (status in ('Pendente','Devolvido')),
  devolvido_em timestamptz,
  devolvido_por uuid,
  observacao text not null default ''
);
alter table public.reembolsos enable row level security;
do $$ begin
  if not exists (select 1 from pg_policy where polrelid='public.reembolsos'::regclass and polname='reembolsos_ler') then
    create policy reembolsos_ler on public.reembolsos for select to authenticated using (public.tem_nivel('Admin','Operador'));
  end if;
end $$;
revoke all on public.reembolsos from anon, authenticated;
grant select on public.reembolsos to authenticated;

create or replace function public._reembolso_ao_cancelar() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.status::text = 'Cancelada' and old.status::text <> 'Cancelada' and new.status_pagamento::text = 'Pago' then
    insert into public.reembolsos (venda_id, valor, forma_pagamento, motivo, cancelado_por)
    values (new.id, new.valor_total, coalesce(new.forma_pagamento,''), coalesce(new.motivo_cancelamento,''), auth.uid())
    on conflict (venda_id) do nothing;
  end if;
  return new;
end $$;
revoke execute on function public._reembolso_ao_cancelar() from public, anon, authenticated;

create or replace trigger trg_reembolso_ao_cancelar after update of status on public.vendas
for each row execute function public._reembolso_ao_cancelar();

create or replace function public.api_listar_reembolsos(p jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_st text := nullif(btrim(coalesce(p->>'status','')),'');
begin
  if not tem_nivel('Admin','Operador') then return _negado(); end if;
  return jsonb_build_object('ok', true, 'itens', coalesce((
    select jsonb_agg(jsonb_build_object('id', r.id, 'vendaId', r.venda_id, 'numero', v.numero_pedido, 'cliente', v.cliente_nome,
      'valor', r.valor, 'forma', r.forma_pagamento, 'motivo', r.motivo, 'status', r.status, 'criadoEm', r.criado_em,
      'devolvidoEm', r.devolvido_em, 'observacao', r.observacao) order by r.criado_em desc)
    from reembolsos r join vendas v on v.id = r.venda_id
    where v_st is null or r.status = v_st), '[]'::jsonb));
end $$;
revoke execute on function public.api_listar_reembolsos(jsonb) from public, anon;
grant execute on function public.api_listar_reembolsos(jsonb) to authenticated;

create or replace function public.api_confirmar_reembolso(p jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_id uuid := _uuid(p->>'id'); r reembolsos%rowtype; v_login text;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  select * into r from reembolsos where id = v_id for update;
  if not found then return _falha('Reembolso não encontrado.'); end if;
  if r.status = 'Devolvido' then return _falha('Este reembolso já foi marcado como devolvido.'); end if;
  update reembolsos set status = 'Devolvido', devolvido_em = now(), devolvido_por = auth.uid(),
         observacao = left(btrim(coalesce(p->>'observacao','')), 300) where id = r.id;
  select login into v_login from usuarios where id = auth.uid();
  perform _auditar('Reembolso devolvido', 'Venda ' || r.venda_id || ' | R$ ' || _dinheiro(r.valor) || ' | por ' || coalesce(v_login,''), '');
  return jsonb_build_object('ok', true, 'message', 'Devolução registrada.');
end $$;
revoke execute on function public.api_confirmar_reembolso(jsonb) from public, anon;
grant execute on function public.api_confirmar_reembolso(jsonb) to authenticated;

-- Ajuda (usada pela IA): tópico do manual do Administrador
insert into public.ai_ajuda (slug,titulo,palavras_chave,passos,perfis,ativo,grupo,ordem,comuns)
select 'man-admin-98-reembolsos','Reembolsos de vendas canceladas',
 'reembolso reembolsos devolver devolução estorno venda cancelada paga pix dinheiro cartão pendente devolvido',
 E'Cancelou uma venda que já estava paga? O sistema cria sozinho um reembolso pendente.\nAdministrador → Financeiro → Ajustes pós-venda → "Reembolsos de vendas canceladas".\nDevolva o dinheiro ao cliente (Pix, dinheiro ou estorno no cartão).\nToque em "marcar devolvido" e, se quiser, escreva como foi devolvido.',
 array['Admin'],true,'lista',98,'Só o Administrador marca como devolvido; o Operador consegue ver a lista. Venda cancelada que ainda não estava paga não gera reembolso.'
where not exists (select 1 from ai_ajuda where slug='man-admin-98-reembolsos');
