-- Cria as 3 linhas da configuração do backup automático (sem elas, "Salvar configuração" não grava nada
-- e a caixa volta a ficar desmarcada). Seguro para rodar de novo: não mexe no que já existe.
insert into public.sistema (chave, valor) values
  ('BACKUP_AUTO_ATIVO', 'false'::jsonb),
  ('BACKUP_HORA', '4'::jsonb),
  ('BACKUP_FREQ', '"diario"'::jsonb)
on conflict (chave) do nothing;
select chave, valor from public.sistema where chave like 'BACKUP_%' order by chave;
