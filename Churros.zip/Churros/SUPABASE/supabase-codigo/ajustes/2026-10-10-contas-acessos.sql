-- =====================================================================
-- RESTAURANTE — "Contas e acessos" (Admin → Sistema) · 2026-10-10
-- Lista das contas do sistema (serviço, e-mail, link, observação). Só Admin/Desenvolvedor.
-- A senha de cada conta fica no COFRE do Supabase (Vault, criptografado); a tabela guarda só o id do segredo.
-- Ver a senha exige a senha de administrador (conferida de verdade) e fica registrado na Auditoria.
-- Seguro para rodar de novo.
-- =====================================================================

-- Pré-requisito: senha de administrador conferida de verdade também para quem já é Admin
create or replace function public._exige_admin(p_senha text)
 returns text language plpgsql security definer set search_path to 'public', 'auth', 'extensions' as $function$
declare v_eu usuarios%rowtype; v_chave text; v_adm record; v_ok boolean;
begin
  select * into v_eu from usuarios where id = auth.uid() and ativo;
  if not found then return null; end if;
  v_chave := 'falhas_admin_' || lower(v_eu.login);
  if v_eu.nivel::text in ('Admin','Desenvolvedor') then
    -- quem já é Admin: se informou senha, ela precisa ser a dele; sem senha, segue (telas que não pedem senha ao Admin)
    if coalesce(p_senha, '') <> '' then
      if _excedeu(v_chave, 5) then return null; end if;
      select (au.encrypted_password = crypt(p_senha, au.encrypted_password)) into v_ok from auth.users au where au.id = v_eu.id;
      if not coalesce(v_ok, false) then
        perform _registrar_falha(v_chave);
        perform _auditar('Falha na senha de administrador', 'Tentativa por ' || v_eu.login);
        return null;
      end if;
      perform _limpar_falhas(v_chave);
    end if;
    perform set_config('app.autorizador', v_eu.login, true);
    return v_eu.login;
  end if;
  if coalesce(p_senha, '') = '' then return null; end if;
  if _excedeu(v_chave, 5) then return null; end if;
  select us.login into v_adm from usuarios us join auth.users au on au.id = us.id
    where us.nivel in ('Admin','Desenvolvedor') and us.ativo and au.encrypted_password = crypt(p_senha, au.encrypted_password) limit 1;
  if found then
    perform _limpar_falhas(v_chave);
    perform set_config('app.autorizador', v_adm.login, true);
    return v_adm.login;
  end if;
  perform _registrar_falha(v_chave);
  perform _auditar('Falha na senha de administrador', 'Tentativa por ' || v_eu.login);
  return null;
end $function$;
revoke all on function public._exige_admin(p_senha text) from public, anon, authenticated;

create table if not exists public.contas_acessos (
  id uuid primary key default gen_random_uuid(),
  servico text not null,
  email text not null default '',
  link text not null default '',
  observacao text not null default '',
  senha_id uuid,
  ordem int not null default 0,
  criado_em timestamptz not null default now(),
  atualizado_em timestamptz not null default now()
);
alter table public.contas_acessos enable row level security;
revoke all on table public.contas_acessos from anon, authenticated;

create or replace function public.api_listar_contas(p jsonb default '{}'::jsonb)
 returns jsonb language plpgsql stable security definer set search_path to 'public' as $f$
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  return jsonb_build_object('ok', true, 'contas', coalesce((select jsonb_agg(jsonb_build_object('id', id, 'servico', servico, 'email', email, 'link', link,
           'observacao', observacao, 'temSenha', senha_id is not null) order by ordem, servico) from contas_acessos), '[]'::jsonb));
end $f$;

create or replace function public.api_salvar_conta(p jsonb)
 returns jsonb language plpgsql security definer set search_path to 'public', 'vault' as $f$
declare v_id uuid := _uuid(p->>'id'); c contas_acessos%rowtype; v_serv text := left(btrim(coalesce(p->>'servico', '')), 80);
  v_email text := left(btrim(coalesce(p->>'email', '')), 120); v_link text := left(btrim(coalesce(p->>'link', '')), 500);
  v_obs text := left(btrim(coalesce(p->>'observacao', '')), 500); v_senha text := coalesce(p->>'senha', ''); v_sid uuid;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_serv = '' then return _falha('Informe o nome do serviço (ex.: Supabase, GitHub).'); end if;
  if v_link <> '' and v_link !~* '^https?://' then v_link := 'https://' || v_link; end if;
  if length(v_senha) > 200 then return _falha('Senha longa demais.'); end if;
  if v_id is null then
    insert into contas_acessos (servico, email, link, observacao, ordem) values (v_serv, v_email, v_link, v_obs, coalesce((select max(ordem) + 1 from contas_acessos), 1)) returning * into c;
  else
    update contas_acessos set servico = v_serv, email = v_email, link = v_link, observacao = v_obs, atualizado_em = now() where id = v_id returning * into c;
    if not found then return _falha('Conta não encontrada.'); end if;
  end if;
  if coalesce((p->>'removerSenha')::boolean, false) and c.senha_id is not null then
    delete from vault.secrets where id = c.senha_id; update contas_acessos set senha_id = null where id = c.id;
  elsif v_senha <> '' then
    if c.senha_id is null then
      v_sid := vault.create_secret(v_senha, 'conta_acesso_' || c.id::text, 'Senha da conta ' || v_serv);
      update contas_acessos set senha_id = v_sid where id = c.id;
    else
      perform vault.update_secret(c.senha_id, v_senha);
    end if;
  end if;
  perform _auditar(case when v_id is null then 'Conta cadastrada' else 'Conta editada' end, v_serv || case when v_senha <> '' then ' (senha alterada)' else '' end);
  return jsonb_build_object('ok', true, 'message', 'Conta salva.') || api_listar_contas('{}');
end $f$;

create or replace function public.api_excluir_conta(p jsonb)
 returns jsonb language plpgsql security definer set search_path to 'public', 'vault' as $f$
declare c contas_acessos%rowtype;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  delete from contas_acessos where id = _uuid(p->>'id') returning * into c;
  if not found then return _falha('Conta não encontrada.'); end if;
  if c.senha_id is not null then delete from vault.secrets where id = c.senha_id; end if;
  perform _auditar('Conta excluída', c.servico);
  return jsonb_build_object('ok', true, 'message', 'Conta excluída.') || api_listar_contas('{}');
end $f$;

create or replace function public.api_ver_senha_conta(p jsonb)
 returns jsonb language plpgsql security definer set search_path to 'public', 'vault' as $f$
declare c contas_acessos%rowtype; v text;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if coalesce(p->>'senhaAdmin', '') = '' then return _falha('Informe a sua senha de administrador.'); end if;
  if _exige_admin(p->>'senhaAdmin') is null then return _falha('Senha de administrador incorreta.'); end if;
  select * into c from contas_acessos where id = _uuid(p->>'id');
  if not found or c.senha_id is null then return _falha('Esta conta não tem senha guardada.'); end if;
  select decrypted_secret into v from vault.decrypted_secrets where id = c.senha_id;
  perform _auditar('Senha de conta visualizada', c.servico);
  return jsonb_build_object('ok', true, 'senha', coalesce(v, ''));
end $f$;

revoke execute on function public.api_listar_contas(jsonb), public.api_salvar_conta(jsonb), public.api_excluir_conta(jsonb), public.api_ver_senha_conta(jsonb) from public, anon;
grant execute on function public.api_listar_contas(jsonb), public.api_salvar_conta(jsonb), public.api_excluir_conta(jsonb), public.api_ver_senha_conta(jsonb) to authenticated;

-- contas já conhecidas deste sistema (só se a lista estiver vazia; senhas o Admin preenche no app)
insert into contas_acessos (servico, email, link, observacao, ordem)
select * from (values
  ('Supabase (servidor principal)', 'churrosdeproposito@gmail.com', 'https://supabase.com/dashboard/project/ljipjjzjjnzedcuksmon', 'Banco de dados, login e funções do sistema.', 1),
  ('GitHub (onde a página fica publicada)', 'churrosdeproposito@gmail.com', 'https://github.com/churrosdeproposito/app', 'Suba aqui o index.html a cada atualização.', 2),
  ('Site do sistema', '', 'https://churrosdeproposito.github.io/app/', 'Endereço que a equipe e os clientes abrem (QR Codes).', 3),
  ('Planilha principal (Google Sheets / Apps Script)', 'churrosdeproposito@gmail.com', '', 'Servidor de reserva. Fica no Google Drive desta conta. Coloque aqui o link do Apps Script publicado.', 4),
  ('Planilha de contingência (Google Sheets / Apps Script)', 'churrosdepropositocontingencia@gmail.com', '', 'Último recurso. Conta Google separada só para ela (planilha e Google Drive). Coloque aqui o link do Apps Script publicado.', 5)
) v(s, e, l, o, n)
where not exists (select 1 from contas_acessos);

-- Ajuda do assistente
insert into ai_ajuda (slug,titulo,palavras_chave,passos,perfis,ativo,grupo,ordem,comuns)
select 'man-admin-101-contas-e-acessos','Contas e acessos','contas acessos email senha link supabase github planilha apps script cofre ver senha',
E'Administrador → Sistema → Contas e acessos: lista das contas do sistema (Supabase, GitHub, planilhas…) com e-mail, link e observação.\n"+ Nova conta" cadastra; "Editar" muda os dados ou a senha; "Excluir" apaga a conta e a senha guardada.\nA senha fica no cofre criptografado do Supabase. Para ver, toque em "Ver senha" e digite a SUA senha de administrador; ela aparece por 30 segundos e fica registrado na Auditoria.',
array['Admin'],true,'lista',101,'Nunca mande senhas por mensagem: digite direto nesta tela.'
where not exists (select 1 from ai_ajuda where slug='man-admin-101-contas-e-acessos');
