-- =====================================================================
-- PENTE FINO (11/10/2026)
-- Parte A já foi aplicada no banco pelo Claude. As partes B, C e D são para rodar no SQL Editor
-- (o Supabase pede confirmação para apagar dados ou objetos). Podem rodar mais de uma vez.
-- =====================================================================

-- ---------- A) JÁ APLICADO ----------
-- A1) A cópia para a planilha principal leva só as tabelas que a planilha usa
--     (espelho da contingência, conferência do dia e arquivo de vendas).
create or replace function public.enfileirar_sync()
 returns trigger
 language plpgsql
 security definer
 set search_path to 'public'
as $function$
declare reg jsonb; rid text;
begin
  if current_setting('rst.sem_fila', true) = 'on' then return null; end if;
  if tg_table_name not in ('categorias','produtos','produto_precos','combos','combo_precos','combo_itens','adicionais','produto_adicionais',
                           'formas_pagamento','sistema','clientes','vendas','itens_venda','pagamentos_venda') then return null; end if;
  if tg_op = 'DELETE' then reg := to_jsonb(old); else reg := to_jsonb(new); end if;
  rid := coalesce(reg->>'id', reg->>'chave');
  insert into fila_sync (tabela, registro_id, operacao, payload)
  values (tg_table_name, rid, tg_op::op_sync, case when tg_op = 'DELETE' then null else reg end);
  return null;
end $function$;

-- A2) O analisador de código da IA do Desenvolvedor saiu em 08/10: o diagnóstico não lê mais as tabelas dele.
create or replace function public.ia_diag_codigo()
 returns jsonb
 language plpgsql
 stable
 set search_path to 'public'
as $function$
begin
  if coalesce(ia_nivel_real(), '') <> 'Desenvolvedor' then return jsonb_build_object('ok', false); end if;
  return jsonb_build_object('ok', true, 'existe', false);
end $function$;

-- ---------- B) BEBIDAS SEM ADICIONAIS ----------
-- Produto com estoque próprio (bebida / item comprado pronto) deixa de oferecer adicionais.
delete from produto_adicionais pa using produtos p
 where p.id = pa.produto_id and p.estoque_proprio_ingrediente_id is not null;

-- ---------- C) SOBRAS QUE NINGUÉM USA ----------
drop function if exists public.ia_codigo_catalogo();
drop function if exists public.ia_codigo_faltantes(text, jsonb);
drop function if exists public.ia_codigo_gravar(text, text, jsonb);
drop function if exists public.ia_codigo_registrar_versao(text, text, jsonb);
drop table if exists public.codigo_snapshots, public.codigo_versoes, public.codigo_analises, public.ia_relatorio_codigo;
drop function if exists public.api_cancelar_brinde(jsonb);
drop function if exists public.api_push_cliente_cancelar(jsonb);
drop function if exists public.api_editar_cupom(jsonb);
-- Cópia dos preços de 09/10 (feita antes do preço base único). Só se os preços estão certos:
drop table if exists public.precos_backup_20261009;

-- ---------- D) TEXTOS DA AJUDA DA IA ----------
-- Ajuda da IA (ai_ajuda): textos que mudaram no pente fino de 11/10/2026. Pode rodar mais de uma vez.
update ai_ajuda set passos = replace(passos, 'Sistema (Usuários e Permissões, Auditoria, Backup, Espaço e fotos, Sincronização e contingência)', 'Sistema (Usuários e Permissões, Auditoria, Backup e espaço, Sincronização e contingência, Contas e acessos)'), atualizado_em = now()
 where slug = 'man-admin-02-onde-fica-cada-coisa';
update ai_ajuda set passos = passos || E'\nProduto novo já vem com os adicionais que os outros produtos da mesma categoria têm ("Comprado pronto", como bebida, vem sem nenhum). Desmarque o que não vale.',
       comuns = coalesce(comuns, '') || ' Bebida e item comprado pronto não têm adicionais.', atualizado_em = now()
 where slug = 'man-admin-04-cadastrar-produtos-e-estoque' and passos not like '%mesma categoria têm%';
update ai_ajuda set passos = replace(passos, '(pede motivo)', '(toque num motivo pronto, como "Cliente não atende", ou escreva). Recusar pedido também tem motivos prontos'), atualizado_em = now()
 where slug in ('man-admin-09-pedidos-e-entregas', 'man-operador-05-pedidos-e-entregas', 'pedidos-aceitar-entregas');
update ai_ajuda set passos = replace(passos, 'O interruptor "Sincronização automática do espelho (todo dia às 3h)" liga e desliga a cópia diária do cardápio e dos cadastros para a contingência.', 'O espelho da contingência (cardápio, preços, clientes e pedidos em andamento) se atualiza sozinho a cada 10 minutos e por completo todo dia às 3h. Não há nada para ligar.'), atualizado_em = now()
 where slug = 'man-admin-10-contingencia-e-modo-reserva';
update ai_ajuda set passos = replace(replace(passos, 'Sistema → Espaço e fotos → bloco', 'Sistema → Backup e espaço → bloco'), 'Fotos: só no Google Drive. Administrador → Espaço e fotos → "Copiar fotos antigas para a contingência".', 'Fotos: ficam no Google Drive principal, com cópia no Drive da contingência. É automático.'), atualizado_em = now()
 where slug = 'man-admin-14-arquivamento-e-uso-do-banco';
update ai_ajuda set passos = replace(replace(passos, 'Sistema → Backup → "Fazer backup agora".', 'Sistema → Backup e espaço → "Fazer backup agora" (começa na hora, sem pergunta).'), 'Confira o uso do Drive: até 70% normal, 70–90% atenção, acima de 90% crítico.', 'Na mesma tela ficam "Uso do Supabase" (arquivamento) e "Google Drive" (espaço: até 70% normal, 70–90% atenção, acima de 90% crítico).'), atualizado_em = now()
 where slug = 'man-admin-16-backup-e-armazenamento';
update ai_ajuda set passos = passos || E'\nAo marcar um pedido de compra como recebido, escolha "✅ Já paguei" ou "🕒 Vou pagar depois" (aí aparece o calendário do vencimento).', atualizado_em = now()
 where slug = 'man-admin-93-compras-fornecedores' and passos not like '%Vou pagar depois%';
update ai_ajuda set passos = passos || E'\nEntrada, perda e inventário abrem uma janela só, com a quantidade e o motivo juntos. Na perda, toque num motivo pronto (Estragou, Venceu…) ou escreva o seu.', atualizado_em = now()
 where slug = 'man-admin-97-listas-acoes' and passos not like '%janela só%';
update ai_ajuda set passos = replace(passos, 'e, se quiser, escreva como foi devolvido.', 'e, se quiser, toque em como foi devolvido (Pix, Dinheiro ou Estorno no cartão).'), atualizado_em = now()
 where slug = 'man-admin-98-reembolsos';
