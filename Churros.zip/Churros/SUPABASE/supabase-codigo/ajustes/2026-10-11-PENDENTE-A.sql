-- Cole no SQL Editor do Supabase do Churros e clique Run (4 funções que usam 'excluir', que o conector não aprovou sozinho).
create or replace function public._ifood_gravar_itens(p_venda uuid, p_order jsonb, p_regravar boolean) returns int
 language plpgsql security definer set search_path to 'public' as $f$
declare it jsonb; op jsonb; v_item ifood_itens%rowtype; v_op ifood_itens%rowtype; v_chave text; v_qtd int; v_tot numeric; v_ads uuid[]; v_desc text; v_custo numeric; v_sem int := 0; v_obs text; v_oq int;
begin
  if p_regravar then
    perform _ajustar_estoque(_itens_da_venda(p_venda), -1, p_venda);
    delete from itens_venda where venda_id = p_venda;
  end if;
  for it in select value from jsonb_array_elements(coalesce(p_order->'items', '[]'::jsonb)) loop
    v_chave := coalesce(nullif(it->>'externalCode', ''), nullif(it->>'id', ''), 'sem-codigo-' || public._ifood_norm(it->>'name'));
    v_qtd := greatest(1, round(public._ifood_n(it->'quantity'))::int);
    v_tot := public._ifood_n(it->'totalPrice');
    if v_tot <= 0 then v_tot := public._ifood_n(it->'price'); end if;
    if v_tot <= 0 then v_tot := (public._ifood_n(it->'unitPrice') + public._ifood_n(it->'optionsPrice')) * v_qtd; end if;
    v_item := public._ifood_item_visto(v_chave, it->>'name', 'produto');
    v_ads := '{}'; v_desc := coalesce(it->>'name', 'Item iFood'); v_obs := nullif(btrim(coalesce(it->>'observations', '')), '');
    for op in select value from jsonb_array_elements(coalesce(it->'options', '[]'::jsonb)) loop
      v_op := public._ifood_item_visto(coalesce(nullif(op->>'externalCode', ''), nullif(op->>'id', ''), 'sem-codigo-' || public._ifood_norm(op->>'name')), op->>'name', 'opcao');
      v_oq := greatest(1, round(public._ifood_n(op->'quantity'))::int);
      v_desc := v_desc || ' + ' || coalesce(op->>'name', 'opção') || case when v_oq > 1 then ' x' || v_oq else '' end;
      if v_op.adicional_id is not null then
        for i in 1..(v_oq * v_qtd) loop v_ads := v_ads || v_op.adicional_id; end loop;
      end if;
    end loop;
    if v_obs is not null then v_desc := v_desc || ' (obs: ' || v_obs || ')'; end if;
    v_custo := 0;
    if v_item.produto_id is not null then select coalesce(min(custo), 0) into v_custo from produto_precos where produto_id = v_item.produto_id;
    elsif v_item.combo_id is not null then select coalesce(min(custo), 0) into v_custo from combo_precos where combo_id = v_item.combo_id;
    end if;
    if v_item.produto_id is null and v_item.combo_id is null and not v_item.ignorar then v_sem := v_sem + 1; v_desc := v_desc || ' [SEM LIGAÇÃO]'; end if;
    insert into itens_venda (venda_id, produto_id, combo_id, descricao, quantidade, valor_unitario, custo_unitario, valor_total_item, adicionais_ids)
    values (p_venda, case when v_item.ignorar then null else v_item.produto_id end, case when v_item.ignorar then null else v_item.combo_id end,
            left(v_desc, 300), v_qtd, round(v_tot / v_qtd, 2), round(v_custo, 2), round(v_tot, 2), v_ads);
  end loop;
  perform _ajustar_estoque(_itens_da_venda(p_venda), 1, p_venda);
  return v_sem;
end $f$;

create or replace function public._integracoes_limpar() returns void
 language sql security definer set search_path to 'public' as $f$
  delete from integracoes_log where criado_em < now() - interval '30 days'
$f$;

create or replace function public.api_fiscal_perfil_excluir(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare v_id uuid := (p->>'id')::uuid; v_nome text;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  select nome into v_nome from fiscal_perfis where id = v_id;
  if v_nome is null then return _falha('Perfil não encontrado.'); end if;
  if exists (select 1 from produtos where perfil_fiscal_id = v_id) or exists (select 1 from combos where perfil_fiscal_id = v_id) or exists (select 1 from categorias where perfil_fiscal_id = v_id)
     or exists (select 1 from fiscal_empresa where perfil_padrao_id = v_id) then
    return _falha('Este perfil está em uso. Troque o perfil dos itens antes de excluir (ou desative o perfil).');
  end if;
  delete from fiscal_perfis where id = v_id;
  perform _auditar('Fiscal: perfil excluído', v_nome);
  return api_fiscal_perfis('{}') || jsonb_build_object('message', 'Perfil excluído.');
end $f$;

create or replace function public.ifood_limpar() returns void language plpgsql security definer set search_path to 'public' as $f$
declare v_dias int := coalesce((select (config->>'retencaoClientesDias')::int from integracoes_config where provedor = 'ifood'), 90);
begin
  delete from ifood_eventos where recebido_em < now() - interval '30 days';
  delete from ifood_acoes where criado_em < now() - interval '60 days' and estado in ('ok', 'pulada');
  update ifood_pedidos set bruto = jsonb_set(coalesce(bruto, '{}'::jsonb) - 'customer' - 'delivery', '{apagado}', 'true'::jsonb) where criado_em < now() - make_interval(days => v_dias) and coalesce((bruto->>'apagado'), '') <> 'true';
  update vendas set telefone_cliente = null, endereco = '', complemento = '', referencia = '', cliente_nome = 'Cliente iFood'
   where canal = 'iFood' and data_hora < now() - make_interval(days => v_dias) and (telefone_cliente is not null or endereco <> '' or cliente_nome <> 'Cliente iFood');
end $f$;

revoke execute on function public._ifood_gravar_itens(uuid, jsonb, boolean), public._integracoes_limpar(), public.ifood_limpar() from public, anon, authenticated;
grant execute on function public._ifood_gravar_itens(uuid, jsonb, boolean), public._integracoes_limpar(), public.ifood_limpar() to service_role;
revoke execute on function public.api_fiscal_perfil_excluir(jsonb) from public, anon;
grant execute on function public.api_fiscal_perfil_excluir(jsonb) to authenticated;

-- Limpeza diária do iFood (só depois das funções acima)
select cron.schedule('ifood-limpeza-diaria', '55 6 * * *', $j$select public.ifood_limpar()$j$);
