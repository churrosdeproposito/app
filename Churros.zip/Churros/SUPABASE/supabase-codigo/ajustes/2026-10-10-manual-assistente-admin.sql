-- Manual do Assistente (ai_ajuda) gerado a partir do manual do próprio app. Seguro para rodar de novo: não duplica nem altera linhas que já existem (mesmo slug).
insert into public.ai_ajuda (slug,titulo,palavras_chave,passos,perfis,ativo,grupo,ordem,comuns) values
($t$man-admin-01-entrar-sair-e-status$t$,$t$Entrar, sair e status$t$,$t$entrar, sair e status$t$,$t$Digite Login e Senha e toque em “Entrar”.
Olhe o status no topo: 🟢 Online = tudo certo · 🟡 Sincronizando = aguarde · 🔴 Sem conexão = veja “E se der errado?” · 🟠 Contingência = o servidor está lento ou fora do ar e o app usa a reserva. Toque na bolinha colorida do topo para ver o estado do Supabase, da planilha principal e da contingência.
Para sair, toque em “Sair” no topo. Para trocar a sua senha, toque em “🔑 Senha” (precisa da senha atual e de ao menos 8 caracteres).
Suas abas: Início, Caixa, Pedidos (com Retiradas, Entregas e Mesas), Clientes e Administrador. Os avisos ficam no botão ✨ Assistente, na aba 🔔 Avisos. Um ponto azul numa aba avisa que há algo novo.$t$,array['Admin'],true,'lista',1,$t$“Login ou senha incorretos”: confira os dados. Se esqueceu a senha, só o Administrador pode redefinir. “Sua sessão expirou”: entre de novo; o que você estava digitando pode se perder. “Muitas tentativas erradas”: depois de 5 erros o login fica bloqueado por 10 minutos, contados a partir do primeiro erro. Espere e tente de novo, sem insistir.$t$),
($t$man-admin-02-buscar-no-topo$t$,$t$Buscar (🔍 no topo)$t$,$t$buscar (🔍 no topo)$t$,$t$Toque na lupa 🔍 no topo, digite pelo menos 2 letras ou números e veja clientes (nome ou telefone, sem precisar de acento), pedidos (número, nome ou telefone do cliente) e produtos/combos.
No cliente, toque em "abrir" para ver o perfil. No pedido, toque em "ver pedido completo": aparece também a 🕒 Linha do tempo (feito, aceito, pronto, saiu, entregue e quanto tempo levou cada etapa).$t$,array['Admin'],true,'lista',2,$t$$t$),
($t$man-admin-03-onde-fica-cada-coisa$t$,$t$Onde fica cada coisa$t$,$t$onde fica cada coisa$t$,$t$Ao tocar em Admin, nada abre sozinho: aparecem só os 6 grupos; toque num grupo para ver as telas dele e depois na tela que quer abrir.
A aba Administrador tem uma barra dividida em 6 grupos: Painel (Visão Geral, Ocorrências, Feedbacks, Relatórios); Financeiro (Contas e despesas, Análise, Ajustes pós-venda, Histórico); Catálogo (Produtos, Estoque, Custos e Precificação, Cardápio Digital); Campanhas (Promoções, Eventos); Operação (Mesas e QR Codes, Pagamentos, Entregadores e taxas, Configurar notificações); Sistema (Usuários e Permissões, Auditoria, Backup, Espaço e fotos, Sincronização e contingência, Contas e acessos).
Caixa, Pedidos, Entregas e Clientes funcionam como nos outros perfis, e você pode tudo.$t$,array['Admin'],true,'lista',3,$t$$t$),
($t$man-admin-04-criar-usuario-e-trocar-senha$t$,$t$Criar usuário e trocar senha$t$,$t$criar usuário e trocar senha$t$,$t$Administrador → Sistema → Usuários e Permissões.
Em "Criar acesso", preencha Login e Senha e escolha o perfil (Operador, Garçom, Cozinha, Entregador, Admin ou Desenvolvedor).
Digite "Sua senha de administrador" e toque em "Criar acesso".
Perfil Desenvolvedor: você cria como qualquer outro, mas depois de criado fica travado — só o próprio Desenvolvedor edita ou troca a senha. Nem você nem ele excluem esse acesso.
Para mudar nome, telefone, perfil, situação ou redefinir a senha de alguém, toque em "editar" na lista "Usuários cadastrados". Mudar perfil, situação, senha, ativar, desativar ou excluir pede a SUA senha de administrador (conferida de verdade). No seu próprio acesso o perfil fica travado e a senha se troca em "🔑 Senha".$t$,array['Admin'],true,'lista',4,$t$Entregador não aparece na escolha de entregas: usuário inativo ou sem o perfil Entregador. Funcionário esqueceu a senha: só você troca — não existe "esqueci minha senha". Você esqueceu a sua: rode redefinirSenhaAdminEmergencia no editor do Apps Script.$t$),
($t$man-admin-05-cadastrar-produtos-e-estoque$t$,$t$Cadastrar produtos e estoque$t$,$t$cadastrar produtos e estoque$t$,$t$Administrador → Catálogo → Produtos → "Cadastrar produto".
Informe nome, categoria, preço e custo (a margem aparece sozinha). O preço é o preço base e vale para todas as formas de pagamento. Formas marcadas em Pagamentos como "preço próprio por produto" (ex.: iFood) ganham um campo próprio no produto e no combo; em branco, vale o preço base.
Só abra "⚙️ Opções avançadas" para a ficha técnica (ingredientes). Se uma forma de pagamento cobra a mais (ex.: iFood), cadastre o acréscimo (% ou valor fixo) na própria forma, em Pagamentos.
Se o item tem estoque próprio (bebida), marque a opção e informe quantidade e mínimo.
Para usar o produto como brinde, abra "⚙️ Opções avançadas" e marque "🎁 Este produto é um prêmio": prêmio do cartão fidelidade e/ou prêmio de indicação. Quando você quiser mudar a campanha, é só trocar a marca de produto.$t$,array['Admin'],true,'lista',5,$t$Cada venda baixa o estoque pela ficha técnica. Ingrediente no mínimo gera aviso em 🔔 Avisos (no Assistente), sem bloquear a venda. Ingrediente com mínimo 0 não avisa; para ser avisado, defina um mínimo maior que 0.$t$),
($t$man-admin-06-premios-fidelidade-e-indicacao$t$,$t$Prêmios: fidelidade e indicação$t$,$t$prêmios: fidelidade e indicação$t$,$t$Marque os produtos que podem ser prêmio em Catálogo → Produtos → Editar → "🎁 Este produto é um prêmio".
Clientes → toque no cliente. Com as 10 marcas do cartão, ou com uma indicação pendente, aparece o prêmio para escolher e o botão "🎁 Resgatar prêmio" (ou "Resgatar indicação").
Confirme. O cartão zera (ou a indicação é marcada), o estoque do produto baixa e o custo entra no financeiro. O cliente não paga nada.$t$,array['Admin'],true,'lista',6,$t$O caixa precisa estar aberto: o prêmio fica registrado no turno. "Nenhum prêmio cadastrado": nenhum produto ativo está marcado como prêmio daquele tipo. As indicações pendentes também aparecem em 🔔 Avisos (no Assistente).$t$),
($t$man-admin-07-qr-code-das-mesas$t$,$t$QR Code das mesas$t$,$t$qr code das mesas$t$,$t$Administrador → Operação → Mesas e QR Codes → "📲 QR Codes das mesas".
Escolha a mesa e toque em "🖨️ Imprimir esta mesa" (ou "Imprimir todas"). Também dá para "⬇️ Baixar PNG".
Plastifique e deixe na mesa. O cliente pede pelo celular e você aceita o pedido em Pedidos.
Se alguém espalhar o QR, use "🔄 Gerar novo código" e imprima o QR novo daquela mesa.$t$,array['Admin'],true,'lista',7,$t$O endereço do site está fixo nos QR: o endereço do seu site — se mudar, é preciso imprimir de novo.$t$),
($t$man-admin-08-menu-de-baixo-celular$t$,$t$Menu de baixo (celular)$t$,$t$menu de baixo (celular)$t$,$t$No celular, o menu fica fixo na parte de baixo da tela: Início, Caixa, Pedidos e as outras telas do seu perfil. A aba aberta fica destacada em azul.
Quando há mais telas do que cabem, aparece "Mais" com as demais. Uma bolinha vermelha avisa que há algo novo naquela aba.
No computador o menu continua no topo.$t$,array['Admin'],true,'lista',8,$t$O botão do Assistente sobe um pouco para não ficar em cima do menu.$t$),
($t$man-admin-10-avisos-com-o-app-fechado$t$,$t$Avisos com o app fechado (🔔)$t$,$t$avisos com o app fechado (🔔)$t$,$t$Toque no 🔔 do topo e em "Ligar avisos com o app fechado". Permita as notificações quando o navegador pedir.
Depois disso o celular avisa "Novo pedido" (do cardápio) e "Cliente no atendimento" mesmo com o app fechado ou a tela bloqueada. O aviso não mostra nome nem telefone do cliente.
No iPhone: abra o endereço no Safari, toque em Compartilhar → "Adicionar à Tela de Início" e abra o app por esse ícone antes de ligar. No Android basta ligar.
Para desligar, toque no mesmo botão. Ao sair do sistema, este aparelho deixa de receber os avisos de quem saiu.$t$,array['Admin'],true,'lista',10,$t$O som e a vibração do app aberto continuam como antes.$t$),
($t$man-admin-13-auditoria-e-acessos-ip$t$,$t$Auditoria e acessos (IP)$t$,$t$auditoria e acessos (ip)$t$,$t$Administrador → Sistema → Auditoria: lista as ações sensíveis (descontos, cancelamentos, preços, estoque, usuários, compras), as entradas no sistema ("Login") e as tentativas com senha errada ("Falha de login").
Cada linha mostra quem fez, o perfil, o aparelho e o IP de origem. Use o período e a busca (nome, ação ou IP) para achar algo; mostra até 300 linhas.
Vários "Falha de login" seguidos do mesmo IP podem ser alguém tentando adivinhar a senha: troque a senha do usuário e encerre as sessões dele.
O IP é apagado depois de 90 dias (o restante do registro fica). Em Usuários → sessões abertas, cada aparelho também mostra o IP da entrada.$t$,array['Admin'],true,'lista',13,$t$Auditoria e IPs são só do Administrador e do Desenvolvedor.$t$),
($t$man-admin-14-compras-fornecedores-e-analises-avancadas$t$,$t$Compras, fornecedores e análises avançadas$t$,$t$compras, fornecedores e análises avançadas$t$,$t$Compras e fornecedores (só Administrador): Administrador → Catálogo → "Compras e fornecedores". Cadastre o fornecedor, depois registre a compra: itens do estoque (ou "outro item"), quantidade, unidade e o valor total pago por item.
Compra "Recebida" já soma no estoque e atualiza o custo médio do insumo; "Pedido" só guarda o pedido e você marca como recebida quando chegar. Toda compra recebida vira uma despesa (Paga ou A pagar, com vencimento).
Marque "saiu do caixa" só se o dinheiro saiu da gaveta. Compra já recebida não é cancelada: corrija pelo estoque ou pela despesa. Pedido ainda não recebido pode ser cancelado com motivo.
Assistente (balão ✨): diga, por exemplo, "comprei 30kg de arroz do fornecedor X por R$ 900". A IA só monta um cartão; nada é gravado até você tocar em "Confirmar e gravar". Use "Revisar na tela" para ajustar antes. Fornecedor ou item que a IA não achar bloqueia o botão: cadastre antes.
Relatórios → "Análise avançada": margem líquida por forma de pagamento, vendas por dia da semana e comparação com o mesmo período do ano passado. Também há os períodos "Últimos 90 dias" e "Últimos 12 meses".$t$,array['Admin'],true,'lista',14,$t$Compras e a gravação pela IA são só do Administrador e do Desenvolvedor.$t$),
($t$man-admin-15-cardapio-digital-promocoes-e-eventos$t$,$t$Cardápio Digital, promoções e eventos$t$,$t$cardápio digital, promoções e eventos$t$,$t$Cardápio Digital: escolha o que aparece para o cliente, destaques, ordem e frase de abertura. "Mais Pedidos" é automático.
Se o cliente pedir mais de 1 item com adicionais, os adicionais valem para todos — o cardápio avisa.
Endereço de entrega: o cliente preenche Rua e bairro, NÚMERO e CIDADE (a localização do celular e o CEP já preenchem rua, bairro e cidade). Sem o número o pedido não é enviado. No pedido, o endereço chega como "Rua, Bairro, nº 123 — Cidade".
Abrir ou fechar o cardápio: use o botão "🌐 Cardápio aberto" em Início ou no Caixa. Um toque fecha (com uma mensagem opcional para o cliente) e outro reabre, sem fechar o caixa. Pedido de mesa por QR Code continua valendo. O cardápio só recebe pedidos com o caixa aberto.
Cupom progressivo: em Promoções → novo cupom, escolha o tipo "Progressivo (por faixa)" e escreva uma faixa por linha (ex.: "50 5" e "100 10" = R$ 5 de desconto a partir de R$ 50 e R$ 10 a partir de R$ 100). Vale a maior faixa que o pedido alcança, contando só os itens (sem a taxa de entrega).
Dados do restaurante: nome, endereço, telefone, horário e redes sociais (texto livre) aparecem no rodapé do cardápio do cliente e nas mensagens de WhatsApp e relatórios.
O cliente pode escrever uma observação em cada item; ela aparece na comanda da cozinha e no pedido.
Item "Esgotado": se "bloquear venda sem estoque" estiver ligado (Catálogo → Estoque), o cardápio mostra "Esgotado" no que o estoque não cobre.
No celular, "Mais pedidos", "Destaques" e cada categoria rolam para o lado. O cliente toca no botão "+" para adicionar e na foto para ver o item ampliado. O botão "💬" redondo abre o Atendimento.
Na entrega, o endereço vem com rua e bairro preenchidos pela localização do cliente (só se ele permitir). O número da casa é sempre digitado por ele e o pedido não segue sem ele.
O cardápio abre rápido porque guarda cópia no aparelho do cliente. Mudanças suas aparecem em instantes.
O cardápio só recebe pedidos com o caixa aberto; fechado, aparece "Estamos fechados no momento".
Promoções: cupons. Eventos: custos e recebimentos por evento. Custos e Precificação: simulador de preço; "Aplicar como preço base" vale para todas as formas de pagamento.$t$,array['Admin'],true,'lista',15,$t$$t$),
($t$man-admin-16-caixa-abrir-vender-e-fechar$t$,$t$Caixa: abrir, vender e fechar$t$,$t$caixa: abrir, vender e fechar$t$,$t$Aba Caixa → "Abrir caixa" e informe o fundo de troco.
Em "Iniciar venda": 1. Cliente → 2. Itens → 3. Pagamento e finalizar.
Depois escolha 58mm, 80mm ou A4 e toque em Imprimir, Copiar ou WhatsApp.
Para encerrar, feche o caixa, informe o dinheiro contado e confira a diferença.
Mesas: o botão "🍽️ Mesas" mostra todas as mesas e quem pediu a conta.
Pedido de mesa no Caixa: "Pagar ao sair" deixa na conta; "Pagar agora" cobra na hora.
Se a forma de pagamento tem acréscimo (ex.: iFood), o Caixa mostra o valor a mais e já soma no total e no comprovante. Em pagamento dividido, o acréscimo vale só para a parte paga naquela forma.
Imprimir o pedido: em Pedidos, nos cartões de Retirada e de Mesa, o botão "🖨️ Imprimir pedido da retirada" (ou "da mesa") imprime o cliente, os itens, o total e se já está pago ou se é para cobrar. Todas usam o mesmo modelo de comanda (a da cozinha também); nas entregas ela traz o endereço, a referência e o valor a cobrar. O botão só aparece depois que o pedido foi aceito. O tamanho do papel dessas três impressões se escolhe em Pedidos → Entregas ("Papel da impressão").$t$,array['Admin'],true,'lista',16,$t$"Abra o caixa antes de registrar uma venda". "A soma dos pagamentos precisa bater com o total". Desconto nunca pode zerar a venda; no Caixa pede a sua senha.$t$),
($t$man-admin-17-modo-emergencia-servidor-fora-do-ar$t$,$t$Modo emergência (servidor fora do ar)$t$,$t$modo emergência (servidor fora do ar)$t$,$t$Só funciona no mesmo aparelho em que você já fez login normal ao menos uma vez nos últimos 30 dias. Cada login novo renova o prazo.
Quando o sistema não consegue falar com o servidor (Supabase), aparece a pergunta: "Entrar em MODO EMERGÊNCIA como [seu login]?". A senha é conferida no aparelho.
O que dá: registrar venda de retirada/entrega pela contingência, usando o catálogo da última sincronização. Sem mesa, sem desconto.
O que NÃO dá: abrir/fechar caixa, cancelar, receber pagamento, mexer em estoque, ver financeiro.
Um aviso laranja fixo no topo mostra "MODO EMERGÊNCIA". Um vigia testa o servidor a cada 30 s. Assim que ele responde, o app pede login de novo.
Errar a senha 5 vezes no modo emergência bloqueia por 5 minutos.$t$,array['Admin'],true,'lista',17,$t$$t$),
($t$man-admin-18-contingencia-e-modo-reserva$t$,$t$Contingência e modo reserva$t$,$t$contingência e modo reserva$t$,$t$O Supabase é o servidor principal; a planilha principal é a reserva e a planilha de contingência é o último recurso. Se o Supabase cai, o modo reserva segura o app e a contingência segura o cardápio e as vendas.
No modo reserva: faixa laranja no topo e cartão "Pedidos na reserva (somente consulta)" em Pedidos. Mostra o que estava em andamento no último espelho e o que entrou na fila da contingência.
Ao voltar, o Admin recebe sozinho as vendas da contingência. Falhas ficam na tela de Contingência.
Tempo real (WebSocket) e modo reserva são automáticos.
Administrador → Sistema → Sincronização e contingência: mostra o uso de espaço da planilha de contingência, "🔄 Sincronizar espelho agora" e "⬇️ Trazer vendas pendentes da contingência".
O interruptor "Sincronização automática do espelho (todo dia às 3h)" liga e desliga a cópia diária do cardápio e dos cadastros para a contingência.$t$,array['Admin'],true,'lista',18,$t$$t$),
($t$man-admin-19-fila-de-envio-e-erros-de-sincronizacao$t$,$t$Fila de envio e erros de sincronização$t$,$t$fila de envio e erros de sincronização$t$,$t$Itens como cadastro de cliente, fidelidade, feedback e ocorrência podem ficar guardados no aparelho quando a internet cai. Aparece o botão "na fila" no topo.
Toque nele para ver estado, tentativas e motivo. Você pode tentar de novo, descartar ou enviar agora.
Venda, pagamento, sangria, cancelamento e estoque NUNCA ficam na fila.
Se a sessão expirar com itens na fila, eles viram "com erro" e voltam só quando alguém entrar de novo e tocar em "Tentar de novo".$t$,array['Admin'],true,'lista',19,$t$$t$),
($t$man-admin-20-localizacao-do-entregador$t$,$t$Localização do entregador$t$,$t$localização do entregador$t$,$t$No cartão da entrega, se o status for "Saiu para entrega" e houver entregador atribuído, aparece "📍 Ver localização".
Abre um mapa embutido (Leaflet local) e um botão "Abrir no mapa".
A posição só existe se o entregador estiver com o app aberto e GPS permitido. O envio é a cada ~18 s e só enquanto houver entrega em "Saiu para entrega".
O cliente vê apenas a distância aproximada.$t$,array['Admin'],true,'lista',20,$t$$t$),
($t$man-admin-21-balao-de-atendimento-e-assistente-de-ia$t$,$t$Balão de atendimento e assistente de IA$t$,$t$balão de atendimento e assistente de ia$t$,$t$No canto da tela tem um botão único. Para o cliente, é o atendimento. Para funcionário logado, é o assistente.
A conversa com o assistente continua ao fechar e reabrir o botão ✨. Ela some ao recarregar o app, ao sair da conta ou depois de 2 horas parada. Para começar do zero, toque em "🗑️ Nova conversa".
Dentro do assistente há duas abas: "✨ Conversa" (perguntas à IA e atendimento de clientes) e "🔔 Avisos" (o que antes ficava em Notificações). O botão do canto mostra "🔔 n" quando há aviso.
Em Avisos aparecem só os itens que precisam de você, em grupos que se abrem ao toque: pedidos aguardando aceite, ocorrências, entregas com problema, contas vencidas, falhas do sistema, estoque baixo, cartão fidelidade quase completo, indicações pendentes, aniversariantes do mês e clientes inativos. O que está em dia fica numa linha só ("✅ Em dia: …").
Quais avisos aparecem para cada perfil se escolhe em Administrador → Operação → Configurar notificações. Botões como "Tratar" abrem a tela da ocorrência por cima.
Assistente (Admin e Operador, só leitura): escreva em português. Exemplos: "como faço uma venda?", "quanto tem de arroz no estoque?", "tem cliente aguardando?", "qual produto vendeu mais hoje?".
Período: reconhece "hoje", "ontem", "7 dias", "30 dias", "mês". Pergunta de mês anterior avisa que os dados estão arquivados (veja Relatórios).
A IA é somente leitura. Não altera preço, não cancela, não muda status. Ela só responde assuntos do restaurante e nunca mostra senha nem dados de contato de clientes. O Operador recebe só o que é da função de Caixa.
Para o cliente, o balão é o atendente virtual: responde cardápio, preços, promoções, formas de pagamento e andamento do pedido (pelo celular dele). Se for problema, oferece "Falar com a equipe"; aí o chamado aparece para você no balão (aba Conversa).
Se a IA ficar sem cota ou fora do ar, o cliente continua vendo o botão para falar com a equipe, que não depende da IA.
Quando o Supabase cai (ou a IA falha seguidas vezes), o balão avisa e o sistema segue normal.$t$,array['Admin'],true,'lista',21,$t$$t$),
($t$man-admin-22-baixar-para-o-excel-csv$t$,$t$Baixar para o Excel (CSV)$t$,$t$baixar para o excel (csv)$t$,$t$Administrador → Relatórios: escolha o período e toque em "⬇️ Baixar este relatório (CSV)" para o relatório na tela.
Em "Dados completos do período" baixe Vendas, Itens vendidos ou Despesas. Meses já arquivados entram sozinhos (as despesas só se estiverem no app). O arquivo abre direto no Excel, com acentos corretos.$t$,array['Admin'],true,'lista',22,$t$$t$),
($t$man-admin-23-arquivamento-e-uso-do-banco$t$,$t$Arquivamento e uso do banco$t$,$t$arquivamento e uso do banco$t$,$t$Administrador → Sistema → Espaço e fotos → bloco "Uso do Supabase".
Por padrão, vendas e caixas fechados com mais de 90 dias saem do Supabase e vão para a planilha (abas Arquivo_*), de madrugada. Você pode mudar a regra (90/60/30 dias) e forçar "Mandar para a planilha agora".
"Proteção de espaço": se o uso chegar a 90%, 95% ou 98% do limite (você escolhe), o sistema manda para a planilha as vendas e caixas já encerrados, mesmo com menos de 30 dias. O que tem menos de 1 dia, os pedidos em andamento e o caixa aberto nunca saem; só apaga o que a planilha confirmou. Verifica de hora em hora.
Relatórios e Visão Geral buscam esse arquivo automaticamente quando o período pedido é antigo.
Fotos: só no Google Drive. Administrador → Espaço e fotos → "Copiar fotos antigas para a contingência".$t$,array['Admin'],true,'lista',23,$t$$t$),
($t$man-admin-24-exemplos-de-pergunta-ao-assistente$t$,$t$Exemplos de pergunta ao assistente$t$,$t$exemplos de pergunta ao assistente$t$,$t$"Resumo de hoje" — faturamento, pedidos, ticket.
"Como estão as vendas comparadas com ontem?"
"Qual produto vendeu mais nos últimos 7 dias?"
"Em que horário vendemos mais?"
"Tem algo fora do normal?" — anomalias do dia.
"O que precisa comprar?" — sugestão de compras pelo consumo.
"Como cancelo uma venda?" / "Como fecho o caixa?" — passo a passo do manual.$t$,array['Admin'],true,'lista',24,$t$$t$),
($t$man-admin-25-backup-e-armazenamento$t$,$t$Backup e armazenamento$t$,$t$backup e armazenamento$t$,$t$Administrador → Sistema → Backup → "Fazer backup agora".
Ative o backup automático e escolha o horário e a retenção (por quantos dias guardar).
Para restaurar, escolha o backup no histórico e confirme com sua senha de administrador.
Para apagar um backup, toque em "Excluir" no histórico e confirme com a sua senha de administrador.
Se o backup ficou sem cópia no Drive, aparece o motivo e o botão "Enviar ao Drive" para tentar de novo. O backup tenta até 3 vezes sozinho.
Confira o uso do Drive: até 70% normal, 70–90% atenção, acima de 90% crítico.$t$,array['Admin'],true,'lista',25,$t$Drive cheio: backups e fotos podem falhar. A conferência de integridade compara, todo dia às 6h10, as vendas do dia anterior no Supabase e na planilha e avisa se o número não bate.$t$),
($t$man-admin-26-ocorrencias$t$,$t$Ocorrências$t$,$t$ocorrências$t$,$t$Você trata direto pelo Assistente: aba "🔔 Avisos" → "⚠️ Ocorrências abertas" → botão "Tratar".
A tela completa (com filtro Abertas/Todas) continua em Administrador → Painel → Ocorrências.$t$,array['Admin'],true,'lista',26,$t$$t$),
($t$man-admin-27-ajustes-pos-venda-reembolso-credito-cortesia$t$,$t$Ajustes pós-venda (reembolso, crédito, cortesia)$t$,$t$ajustes pós-venda (reembolso, crédito, cortesia)$t$,$t$Administrador → Financeiro → Ajustes pós-venda.
Busque a venda (nº do pedido, nome ou telefone) — só aparecem pedidos já entregues.
Escolha o tipo (Reembolso em dinheiro, Crédito para próxima compra, Cortesia ou Desconto retroativo), o valor e o motivo.
Em reembolso e desconto retroativo, escolha se o dinheiro sai do caixa (o caixa precisa estar aberto) ou fora dele.
Toque em "Registrar ajuste". Para desfazer, use "cancelar" na lista, com o motivo.$t$,array['Admin'],true,'lista',27,$t$A venda original NÃO muda. No DRE o ajuste aparece como "Ajustes pós-venda". Crédito não reduz o resultado na hora: quando o cliente usar, aplique como desconto no Caixa. Reembolso e desconto retroativo não passam do valor da venda (somando ajustes já feitos).$t$),
($t$man-admin-28-desenvolvedor-exclusivo$t$,$t$Desenvolvedor (exclusivo)$t$,$t$desenvolvedor (exclusivo)$t$,$t$Esta seção só aparece para quem entrou com acesso de nível Desenvolvedor (e sem "Ver como"). Ninguém mais vê.
Barra "Modo Desenvolvedor — vendo o sistema como:". Escolha um perfil (Operador, Garçom, Cozinha, Entregador) ou uma PESSOA específica e a tela muda para a dela. Suas ações continuam com acesso total.
Voltar para a visão normal: selecione "Admin (visão normal)".
Auto-teste da Ajuda (também no console): testarAjuda_() — valida os 7 manuais em sequência e devolve o resultado.
Painel de uso da IA (custo, erros e cota): dentro do balão (✨) → "Uso da IA". A IA de análise de código do Desenvolvedor foi retirada.
Diagnóstico do sistema: Administrador → Sistema → Sincronização e contingência → "Conferência de integridade". Somente leitura.
Ao criar/editar usuário Desenvolvedor: você cria como qualquer outro, mas depois de criado o acesso fica travado. Nem você nem ele excluem. Só o próprio Desenvolvedor edita a senha.
O servidor sempre confere o nível de quem pede; não adianta forçar "Ver como" para ganhar acesso.$t$,array['Desenvolvedor'],true,'lista',28,$t$$t$),
($t$man-admin-29-i-sobre-o-sistema$t$,$t$ℹ️ Sobre o sistema$t$,$t$ℹ️ sobre o sistema$t$,$t$Versão em uso neste aparelho: 1.0 — publicada em 10/10/2026.
A Ajuda é atualizada junto com o sistema. Se algum passo aqui não bater com a tela, recarregue a página (Ctrl+Shift+R no computador, ou feche e reabra o app no celular).
Esta versão inclui: aviso de pedido novo em segundos, modo reserva automático (Supabase), modo emergência (servidor fora do ar), fila de envio para cadastros, confirmação de impressão da comanda + alerta "PEDIDO ALTERADO", localização do entregador, balão único com IA, arquivamento automático (por idade e por espaço), prêmios de fidelidade e indicação, atendente virtual no cardápio e backup com exclusão e reenvio ao Drive.
Para dúvida ou problema: use o balão de atendimento (canto da tela) ou fale com o responsável técnico.
O app registra erros de JavaScript deste aparelho e envia para o Supabase (com o login de quem estava usando). Nada de dado pessoal de cliente sai por esse caminho.$t$,array['Admin'],true,'lista',29,$t$$t$)
on conflict (slug) do nothing;
