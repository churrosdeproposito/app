-- Custo automático pela receita + conversão de unidade + preços em lote · 2026-10-11 · seguro para rodar de novo
-- Regras:
--  * Produto COM receita (produto_ingredientes): custo = soma(qtd × custo do ingrediente). Vale para todas as formas de pagamento.
--  * Produto SEM receita: mantém o custo digitado.
--  * Combo com itens: custo = soma(qtd × custo de cada produto).
--  * Mudou o custo de um ingrediente (edição, compra recebida, lote) -> recalcula produtos e combos que o usam.
--  * Trocou a unidade do ingrediente entre kg<->g ou l<->ml -> as quantidades das receitas e adicionais são convertidas.

create or replace function public._custo_receita(p_prod uuid) returns numeric
language sql stable security definer set search_path = public as $$
  select round(sum(pi.quantidade_por_unidade * coalesce(e.custo_unitario, 0)), 2)
  from produto_ingredientes pi join estoque e on e.id = pi.ingrediente_id
  where pi.produto_id = p_prod
$$;

create or replace function public._custo_combo(p_combo uuid) returns numeric
language sql stable security definer set search_path = public as $$
  select round(sum(ci.quantidade * coalesce((select max(pp.custo) from produto_precos pp where pp.produto_id = ci.produto_id), 0)), 2)
  from combo_itens ci where ci.combo_id = p_combo
$$;

-- 1) preço do produto gravado/alterado: se tem receita, o custo é o da receita
create or replace function public._trg_produto_precos_custo() returns trigger
language plpgsql security definer set search_path = public as $$
declare v numeric;
begin
  v := _custo_receita(new.produto_id);
  if v is not null then new.custo := v; end if;
  return new;
end $$;
create or replace trigger trg_produto_precos_custo before insert or update on public.produto_precos
for each row execute function public._trg_produto_precos_custo();

-- 2) preço do combo gravado/alterado: se tem itens, o custo é a soma dos produtos
create or replace function public._trg_combo_precos_custo() returns trigger
language plpgsql security definer set search_path = public as $$
declare v numeric;
begin
  v := _custo_combo(new.combo_id);
  if v is not null then new.custo := v; end if;
  return new;
end $$;
create or replace trigger trg_combo_precos_custo before insert or update on public.combo_precos
for each row execute function public._trg_combo_precos_custo();

-- 3) receita mudou -> recalcula o custo do produto (uma vez por comando, não por linha)
create or replace function public._recalc_produtos(p_ids uuid[]) returns void
language plpgsql security definer set search_path = public as $$
begin
  update produto_precos pp set custo = _custo_receita(pp.produto_id)
  where pp.produto_id = any(p_ids)
    and _custo_receita(pp.produto_id) is not null
    and pp.custo is distinct from _custo_receita(pp.produto_id);
end $$;
create or replace function public._trg_receita_ins() returns trigger language plpgsql security definer set search_path = public as $$
begin perform _recalc_produtos(array(select distinct produto_id from novos)); return null; end $$;
create or replace function public._trg_receita_upd() returns trigger language plpgsql security definer set search_path = public as $$
begin perform _recalc_produtos(array(select produto_id from novos union select produto_id from antigos)); return null; end $$;
create or replace function public._trg_receita_del() returns trigger language plpgsql security definer set search_path = public as $$
begin perform _recalc_produtos(array(select distinct produto_id from antigos)); return null; end $$;
create or replace trigger trg_receita_ins after insert on public.produto_ingredientes referencing new table as novos for each statement execute function public._trg_receita_ins();
create or replace trigger trg_receita_upd after update on public.produto_ingredientes referencing old table as antigos new table as novos for each statement execute function public._trg_receita_upd();
create or replace trigger trg_receita_del after delete on public.produto_ingredientes referencing old table as antigos for each statement execute function public._trg_receita_del();

-- 4) itens do combo mudaram -> recalcula o custo do combo
create or replace function public._recalc_combos(p_ids uuid[]) returns void
language plpgsql security definer set search_path = public as $$
begin
  update combo_precos cp set custo = _custo_combo(cp.combo_id)
  where cp.combo_id = any(p_ids)
    and _custo_combo(cp.combo_id) is not null
    and cp.custo is distinct from _custo_combo(cp.combo_id);
end $$;
create or replace function public._trg_combo_itens_ins() returns trigger language plpgsql security definer set search_path = public as $$
begin perform _recalc_combos(array(select distinct combo_id from novos)); return null; end $$;
create or replace function public._trg_combo_itens_upd() returns trigger language plpgsql security definer set search_path = public as $$
begin perform _recalc_combos(array(select combo_id from novos union select combo_id from antigos)); return null; end $$;
create or replace trigger trg_combo_itens_ins after insert on public.combo_itens referencing new table as novos for each statement execute function public._trg_combo_itens_ins();
create or replace trigger trg_combo_itens_upd after update on public.combo_itens referencing old table as antigos new table as novos for each statement execute function public._trg_combo_itens_upd();

-- 5) custo de produto mudou -> recalcula combos que usam o produto
create or replace function public._trg_precos_combos_ins() returns trigger language plpgsql security definer set search_path = public as $$
begin perform _recalc_combos(array(select distinct ci.combo_id from combo_itens ci where ci.produto_id in (select produto_id from novos))); return null; end $$;
create or replace function public._trg_precos_combos_upd() returns trigger language plpgsql security definer set search_path = public as $$
begin perform _recalc_combos(array(select distinct ci.combo_id from combo_itens ci where ci.produto_id in (select n.produto_id from novos n join antigos o on o.id = n.id where n.custo is distinct from o.custo))); return null; end $$;
create or replace trigger trg_precos_combos_ins after insert on public.produto_precos referencing new table as novos for each statement execute function public._trg_precos_combos_ins();
create or replace trigger trg_precos_combos_upd after update on public.produto_precos referencing old table as antigos new table as novos for each statement execute function public._trg_precos_combos_upd();

-- 6) custo do ingrediente mudou -> recalcula produtos que o usam
create or replace function public._trg_estoque_custo() returns trigger language plpgsql security definer set search_path = public as $$
begin
  perform _recalc_produtos(array(select distinct produto_id from produto_ingredientes where ingrediente_id = new.id));
  return null;
end $$;
create or replace trigger trg_estoque_custo after update of custo_unitario on public.estoque
for each row when (old.custo_unitario is distinct from new.custo_unitario) execute function public._trg_estoque_custo();

-- 7) unidade do ingrediente trocou entre kg<->g ou l<->ml -> converte receitas e adicionais
create or replace function public._trg_estoque_unidade() returns trigger language plpgsql security definer set search_path = public as $$
declare f numeric;
begin
  f := _converter_unidade(1, old.unidade::text, new.unidade::text);
  if f is null or f = 1 then return null; end if;
  update produto_ingredientes set quantidade_por_unidade = quantidade_por_unidade * f where ingrediente_id = new.id;
  update adicionais set quantidade_descontar = case when coalesce(quantidade_descontar, 0) = 0 then f else quantidade_descontar * f end
   where ingrediente_id = new.id;
  return null;
end $$;
create or replace trigger trg_estoque_unidade after update of unidade on public.estoque
for each row when (old.unidade is distinct from new.unidade) execute function public._trg_estoque_unidade();

revoke execute on function public._custo_receita(uuid), public._custo_combo(uuid), public._recalc_produtos(uuid[]), public._recalc_combos(uuid[]),
  public._trg_produto_precos_custo(), public._trg_combo_precos_custo(), public._trg_receita_ins(), public._trg_receita_upd(), public._trg_receita_del(),
  public._trg_combo_itens_ins(), public._trg_combo_itens_upd(), public._trg_precos_combos_ins(), public._trg_precos_combos_upd(),
  public._trg_estoque_custo(), public._trg_estoque_unidade() from public, anon, authenticated;

-- 8) editar produto: grava a receita ANTES dos preços (assim o custo digitado só vale para produto sem receita)
create or replace function public.api_editar_produto(p jsonb)
 returns jsonb language plpgsql security definer set search_path to 'public'
as $function$
declare pr produtos%rowtype; v_id uuid := _uuid(p->>'id'); v_nome text := btrim(coalesce(p->>'nome', '')); v_proprio uuid; v_det text;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  select * into pr from produtos where id = v_id;
  if not found then return _falha('Produto não encontrado.'); end if;
  if _versao_conflita(p, 'produtos', v_id) then return _conflito('Este registro foi alterado por outra pessoa enquanto você editava. A tela foi atualizada — confira e edite de novo.'); end if;
  if v_nome = '' then return _falha('Informe o nome do produto.'); end if;
  if jsonb_typeof(p->'precos') = 'array' then
    select coalesce(string_agg(f.nome || ': R$ ' || to_char(a.preco, 'FM999990.00') || ' → R$ ' || to_char(_num(e->>'preco'), 'FM999990.00'), '; '), '') into v_det
    from jsonb_array_elements(p->'precos') e
    join produto_precos a on a.produto_id = v_id and a.forma_pagamento_id = _uuid(e->>'formaPagamentoId')
    join formas_pagamento f on f.id = a.forma_pagamento_id
    where a.preco <> _num(e->>'preco');
  end if;
  v_proprio := _estoque_proprio(pr.estoque_proprio_ingrediente_id, v_nome, p->'estoqueProprio');
  update produtos set nome = v_nome, descricao = coalesce(p->>'descricao', ''), categoria_id = _uuid(p->>'categoria'),
         ativo = (coalesce(p->>'ativo','') <> 'false'), estoque_proprio_ingrediente_id = v_proprio where id = v_id;
  if p ? 'destaque' then update produtos set destaque = coalesce((p->>'destaque')::boolean, false) where id = v_id; end if;
  if p ? 'premioFidelidade' then update produtos set premio_fidelidade = coalesce((p->>'premioFidelidade')::boolean, false) where id = v_id; end if;
  if p ? 'premioIndicacao' then update produtos set premio_indicacao = coalesce((p->>'premioIndicacao')::boolean, false) where id = v_id; end if;
  perform _produto_gravar_receita(v_id, p->'ingredientes', v_proprio);
  if jsonb_typeof(p->'precos') = 'array' then perform _produto_gravar_precos(v_id, p->'precos'); end if;
  if p ? 'adicionaisIds' then perform _produto_gravar_adicionais(v_id, p->'adicionaisIds'); end if;
  perform _auditar('Produto editado', v_nome || case when coalesce(v_det, '') <> '' then ' — Preços alterados: ' || v_det else '' end);
  return jsonb_build_object('ok', true, 'message', 'Produto atualizado.');
end $function$;

-- 9) preços (e unidade) de vários ingredientes de uma vez
create or replace function public.api_salvar_precos_lote(p jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare x jsonb; e estoque%rowtype; v_un text; v_c numeric; f numeric; n int := 0;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if jsonb_typeof(p->'itens') <> 'array' or jsonb_array_length(p->'itens') = 0 then return _falha('Nada para salvar.'); end if;
  if jsonb_array_length(p->'itens') > 400 then return _falha('Muitos itens de uma vez.'); end if;
  for x in select value from jsonb_array_elements(p->'itens') loop
    select * into e from estoque where id = _uuid(x->>'id') for update;
    if not found then continue; end if;
    v_un := lower(coalesce(nullif(btrim(x->>'unidade'), ''), e.unidade::text));
    if v_un not in ('un','g','kg','ml','l') then raise exception 'Unidade inválida em "%".', e.ingrediente; end if;
    f := case when v_un <> e.unidade::text then _converter_unidade(1, e.unidade::text, v_un) end;
    v_c := case when x ? 'custo' and nullif(btrim(x->>'custo'), '') is not null then _num(x->>'custo', -1)
                when f is not null then e.custo_unitario / f else e.custo_unitario end;
    if v_c < 0 or v_c > 999999 then raise exception 'Preço inválido em "%".', e.ingrediente; end if;
    if v_un is distinct from e.unidade::text or round(v_c, 4) is distinct from e.custo_unitario then
      update estoque set unidade = v_un::unidade_estoque, custo_unitario = round(v_c, 4),
             quantidade = case when f is not null then quantidade * f else quantidade end,
             quantidade_minima = case when f is not null then quantidade_minima * f else quantidade_minima end
       where id = e.id;
      n := n + 1;
    end if;
  end loop;
  if n > 0 then perform _auditar('Preços de ingredientes em lote', n || ' ingrediente(s) atualizado(s)'); end if;
  return jsonb_build_object('ok', true, 'message', case when n = 0 then 'Nada mudou.' else n || ' ingrediente(s) atualizado(s). Custos dos produtos recalculados.' end, 'alterados', n);
exception when others then
  if sqlstate = 'P0001' then return _falha(sqlerrm); end if;
  raise;
end $$;
revoke execute on function public.api_salvar_precos_lote(jsonb) from public, anon;
grant execute on function public.api_salvar_precos_lote(jsonb) to authenticated;
