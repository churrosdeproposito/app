-- Manual do Assistente (ai_ajuda) gerado a partir do manual do próprio app. Seguro para rodar de novo: não duplica nem altera linhas que já existem (mesmo slug).
insert into public.ai_ajuda (slug,titulo,palavras_chave,passos,perfis,ativo,grupo,ordem,comuns) values
($t$man-operador-01-menu-de-baixo-celular$t$,$t$Menu de baixo (celular)$t$,$t$menu de baixo (celular)$t$,$t$No celular, o menu fica fixo na parte de baixo da tela: Início, Caixa, Pedidos e as outras telas do seu perfil. A aba aberta fica destacada em azul.
Quando há mais telas do que cabem, aparece "Mais" com as demais. Uma bolinha vermelha avisa que há algo novo naquela aba.
No computador o menu continua no topo.$t$,array['Operador'],true,'lista',1,$t$O botão do Assistente sobe um pouco para não ficar em cima do menu.$t$),
($t$man-operador-02-modo-reserva-quando-o-sistema-cai$t$,$t$Modo reserva (quando o sistema cai)$t$,$t$modo reserva (quando o sistema cai)$t$,$t$Uma faixa laranja "Modo reserva" no topo avisa que o servidor principal está fora.
Você continua vendendo no Caixa (retirada ou entrega, sem desconto e sem cupom) e vendo os pedidos em Pedidos. Pedidos do cardápio também entram.
Mudar status do pedido, estoque e compras ficam indisponíveis até voltar: anote à mão e lance depois.
Cadastro de cliente, fidelidade, feedback e ocorrência vão para uma fila e seguem sozinhos na volta. Não repita a ação.$t$,array['Operador'],true,'lista',2,$t$Quando a faixa sumir, confira se os pedidos feitos na queda aparecem em Pedidos.$t$),
($t$man-operador-03-avisos-com-o-app-fechado$t$,$t$Avisos com o app fechado (🔔)$t$,$t$avisos com o app fechado (🔔)$t$,$t$Toque no 🔔 do topo e em "Ligar avisos com o app fechado". Permita as notificações quando o navegador pedir.
Depois disso o celular avisa "Novo pedido" (do cardápio) e "Cliente no atendimento" mesmo com o app fechado ou a tela bloqueada. O aviso não mostra nome nem telefone do cliente.
No iPhone: abra o endereço no Safari, toque em Compartilhar → "Adicionar à Tela de Início" e abra o app por esse ícone antes de ligar. No Android basta ligar.
Para desligar, toque no mesmo botão. Ao sair do sistema, este aparelho deixa de receber os avisos de quem saiu.$t$,array['Operador'],true,'lista',3,$t$O som e a vibração do app aberto continuam como antes.$t$),
($t$man-operador-04-entrar-sair-e-status$t$,$t$Entrar, sair e status$t$,$t$entrar, sair e status$t$,$t$Digite Login e Senha e toque em “Entrar”.
Olhe o status no topo: 🟢 Online = tudo certo · 🟡 Sincronizando = aguarde · 🔴 Sem conexão = veja “E se der errado?” · 🟠 Contingência = o servidor está lento ou fora do ar e o app usa a reserva. Toque na bolinha colorida do topo para ver o estado do Supabase, da planilha principal e da contingência.
Para sair, toque em “Sair” no topo. Para trocar a sua senha, toque em “🔑 Senha” (precisa da senha atual e de ao menos 8 caracteres).
Suas abas: Início, Caixa, Pedidos (com Retiradas, Entregas e Mesas), Clientes e Operação (Ocorrências e Feedbacks). Os avisos ficam no botão ✨ Assistente, na aba 🔔 Avisos. Um ponto azul numa aba avisa que há algo novo.$t$,array['Operador'],true,'lista',4,$t$“Login ou senha incorretos”: confira os dados. Se esqueceu a senha, só o Administrador pode redefinir. “Sua sessão expirou”: entre de novo; o que você estava digitando pode se perder. “Muitas tentativas erradas”: depois de 5 erros o login fica bloqueado por 10 minutos, contados a partir do primeiro erro. Espere e tente de novo, sem insistir.$t$),
($t$man-operador-05-buscar-no-topo$t$,$t$Buscar (🔍 no topo)$t$,$t$buscar (🔍 no topo)$t$,$t$Toque na lupa 🔍 no topo, digite pelo menos 2 letras ou números e veja clientes (nome ou telefone, sem precisar de acento), pedidos (número, nome ou telefone do cliente) e produtos/combos.
No cliente, toque em "abrir" para ver o perfil. No pedido, toque em "ver pedido completo": aparece também a 🕒 Linha do tempo (feito, aceito, pronto, saiu, entregue e quanto tempo levou cada etapa).$t$,array['Operador'],true,'lista',5,$t$$t$),
($t$man-operador-06-abrir-o-caixa$t$,$t$Abrir o caixa$t$,$t$abrir o caixa$t$,$t$Aba Caixa → "Abrir caixa".
Informe o fundo de troco e confirme.$t$,array['Operador'],true,'lista',6,$t$Sem caixa aberto não há venda, despesa nem sangria, e o Cardápio Digital não recebe pedidos. "Já existe um caixa aberto": feche o anterior antes.$t$),
($t$man-operador-07-fazer-uma-venda$t$,$t$Fazer uma venda$t$,$t$fazer uma venda$t$,$t$1. Cliente: busque por nome ou telefone, ou "Venda sem cadastro". Escolha Retirada, Entrega ou Mesa.
2. Itens: toque nos produtos; adicionais abrem numa janela.
3. Pagamento e finalizar: escolha a forma. Em dinheiro, informe o recebido e veja o troco. Para dividir, marque "Dividir pagamento". Confira o total, escolha 58mm, 80mm ou A4 e toque em Imprimir, Copiar ou WhatsApp.
"↺ Repetir última venda" recarrega o carrinho anterior.$t$,array['Operador'],true,'lista',7,$t$"Abra o caixa antes de registrar uma venda." "A soma dos pagamentos precisa bater com o total". Desconto (% ou R$) pede a senha do administrador.$t$),
($t$man-operador-08-cliente-cancelou-o-pedido-cardapio$t$,$t$Cliente cancelou o pedido (Cardápio)$t$,$t$cliente cancelou o pedido (cardápio)$t$,$t$Nos primeiros 3 minutos, e só enquanto o pedido está "aguardando aceite", o cliente cancela sozinho. O estoque volta.
Depois de aceito, ou passados os 3 minutos, o cliente precisa ligar. Cancelar ou editar passa a ser com você ou o Admin.$t$,array['Operador'],true,'lista',8,$t$$t$),
($t$man-operador-09-pedidos-e-entregas$t$,$t$Pedidos e entregas$t$,$t$pedidos e entregas$t$,$t$Pedido do Cardápio chega como "novo — aguardando aceite": toque em "✅ Aceitar" ou "❌ Rejeitar".
Quando ficar "Pronta" (retirada ou entrega) ou "Saiu para entrega", e o cliente tiver telefone, toque em "📲 Avisar cliente".
Avance com "Marcar como…": Em preparo → Pronta → Retirada (Servida, se for mesa).
Em Entregas, o entregador já vem preenchido quando só existe um cadastrado. Com mais de um, escolha no campo "Entregador".
Para imprimir (o modelo da comanda é o mesmo em todas): nas Entregas toque em "🖨️ Imprimir para o entregador"; nas Retiradas e nas Mesas, em "🖨️ Imprimir pedido da retirada" (ou "da mesa"). O botão aparece depois que o pedido é aceito. Papel (58mm, 80mm ou A4) em Pedidos → Entregas.
Venda "A Receber": quando o cliente pagar, toque em "marcar como recebido".
"⏸ Suspender" pausa o pedido (pede motivo) e "▶️ Retomar" volta.$t$,array['Operador'],true,'lista',9,$t$Só dá para editar os itens com o pedido "Em preparo". O entregador esqueceu de marcar: marque você pelo botão do pedido. Sem aviso de pedido novo: no Início, toque em "🔔 Ativar avisos" e "🔊 Testar som".$t$),
($t$man-operador-10-cliente-pedindo-pela-mesa-qr-code$t$,$t$Cliente pedindo pela mesa (QR Code)$t$,$t$cliente pedindo pela mesa (qr code)$t$,$t$O cliente aponta a câmera para o QR da mesa, escolhe os itens e envia.
O pedido chega em Pedidos como "Recebido" (📱 Cliente). Toque em ✅ Aceitar, ou ❌ Rejeitar.
Se o cliente tocar em "Chamar garçom", a mesa aparece em 🍽️ Mesas com 🔔 — toque em ✔ Atendido quando for lá.
Se tocar em "Pedir a conta", a mesa vira "Pediu a conta" e você fecha como sempre.$t$,array['Operador'],true,'lista',10,$t$O cliente só cancela enquanto o pedido está "Recebido". Pedido de mesa pelo cliente nunca vai ao preparo sem o aceite.$t$),
($t$man-operador-11-fechar-a-conta-de-uma-mesa$t$,$t$Fechar a conta de uma mesa$t$,$t$fechar a conta de uma mesa$t$,$t$Quando o garçom pede a conta, a mesa fica "Aguardando fechamento".
Toque em "🍽️ Mesas". Quem pediu a conta aparece primeiro, com pontinho de aviso e som.
Em cada mesa: garçom, tempo, pedidos e total. "Ver pedidos" mostra o detalhe; "💳 Fechar conta" abre o pagamento.
Para dividir, marque "Dividir em duas formas" e informe o valor da primeira.
Se a forma escolhida tem acréscimo, ele é somado no fechamento e aparece no total a cobrar.$t$,array['Operador'],true,'lista',11,$t$"Abra o caixa antes de fechar a conta da mesa". "A soma dos pagamentos não bate com a conta".$t$),
($t$man-operador-12-editar-ou-cancelar-uma-venda$t$,$t$Editar ou cancelar uma venda$t$,$t$editar ou cancelar uma venda$t$,$t$Caixa → "Lançamentos desde a abertura".
Toque em "editar" ou "excluir".
Cancelar pede motivo e a senha do administrador. Se o pedido já estava pronto, diga se a mercadoria foi perdida ou volta ao estoque.$t$,array['Operador'],true,'lista',12,$t$$t$),
($t$man-operador-13-despesa-e-sangria$t$,$t$Despesa e sangria$t$,$t$despesa e sangria$t$,$t$Caixa → "+ Despesa" ou "− Sangria".
Informe valor e motivo e confirme.$t$,array['Operador'],true,'lista',13,$t$Sangria é retirada de dinheiro do caixa e não conta como despesa.$t$),
($t$man-operador-14-fechar-o-caixa$t$,$t$Fechar o caixa$t$,$t$fechar o caixa$t$,$t$Caixa → fechar caixa.
Informe o dinheiro contado.
Confira o total por forma, despesas, sangrias e a diferença.$t$,array['Operador'],true,'lista',14,$t$Ao tocar em "Sair" com o caixa aberto, o sistema pergunta se você quer mesmo sair.$t$),
($t$man-operador-15-modo-emergencia-servidor-fora-do-ar$t$,$t$Modo emergência (servidor fora do ar)$t$,$t$modo emergência (servidor fora do ar)$t$,$t$Só funciona no mesmo aparelho em que você já fez login normal nos últimos 30 dias.
Quando o sistema não conseguir falar com o servidor (Supabase), oferece "Entrar em MODO EMERGÊNCIA como [seu login]".
Dá para: registrar venda de retirada/entrega pela contingência.
Não dá para: abrir/fechar caixa, cancelar, receber pagamento, mexer em estoque, ver financeiro.
Quando o servidor voltar, o app avisa e pede login de novo.$t$,array['Operador'],true,'lista',15,$t$$t$),
($t$man-operador-16-fila-de-envio$t$,$t$Fila de envio$t$,$t$fila de envio$t$,$t$Cadastro de cliente, fidelidade, feedback e ocorrência podem ficar guardados no aparelho quando a internet cai. Aparece "na fila" no topo.
Toque para ver estado, tentativas e motivo. Você pode tentar de novo, descartar ou enviar agora.
Venda, pagamento, sangria, cancelamento e estoque NUNCA ficam na fila.$t$,array['Operador'],true,'lista',16,$t$$t$),
($t$man-operador-17-balao-de-atendimento$t$,$t$Balão de atendimento$t$,$t$balão de atendimento$t$,$t$O botão no canto é o assistente quando você está logado. Para o cliente ele é o atendente virtual (IA); quando o problema é com a equipe, o chamado chega aqui.
Escreva perguntas como: "como faço uma venda?", "quanto tem de arroz no estoque?", "tem cliente aguardando?".
Se houver cliente esperando, o botão mostra um contador vermelho. Toque para ver a fila e assumir um atendimento.$t$,array['Operador'],true,'lista',17,$t$$t$),
($t$man-operador-18-localizacao-do-entregador$t$,$t$Localização do entregador$t$,$t$localização do entregador$t$,$t$Em Entregas, quando o pedido estiver "Saiu para entrega" e tiver entregador atribuído, aparece "📍 Ver localização".
Abre um mapa com a última posição (o entregador envia a cada ~18 s, só enquanto estiver na rua).$t$,array['Operador'],true,'lista',18,$t$$t$),
($t$man-operador-19-o-que-voce-tem-em-administrador$t$,$t$O que você tem em Administrador$t$,$t$o que você tem em administrador$t$,$t$A aba aparece com o nome "Operação". A barra é reduzida: só o grupo "💬 Atendimento", com duas telas — Ocorrências e Feedbacks.
Ocorrências: filtro Abertas/Todas e botão "Tratar". Você pode mudar status (Aberta → Em andamento → Resolvida), anotar responsável e descrever a solução.
Feedbacks: tudo o que os clientes enviaram. Você pode marcar como Visto ou Respondido.
Atalho mais rápido no dia a dia: no Assistente, a aba "🔔 Avisos" mostra as ocorrências abertas, com botão "Tratar" direto.
Você NÃO tem acesso às outras telas do Administrador (financeiro, usuários, backup, catálogo etc.).$t$,array['Operador'],true,'lista',19,$t$$t$),
($t$man-operador-20-clientes-e-fidelidade$t$,$t$Clientes e fidelidade$t$,$t$clientes e fidelidade$t$,$t$Clientes → "+ Novo cliente": só nome e telefone são obrigatórios.
Toque no cliente para ver histórico, total gasto, indicação e cartão fidelidade.
Com as 10 marcas, ou com uma indicação pendente, escolha o prêmio e toque em "🎁 Resgatar". Precisa do caixa aberto; o estoque baixa e o cliente não paga.
No histórico do cliente, use os filtros de período, entrega/retirada e pago/a receber.$t$,array['Operador'],true,'lista',20,$t$"Nenhum prêmio cadastrado": peça ao Administrador para marcar um produto como prêmio.$t$),
($t$man-operador-21-registrar-um-problema-ocorrencia$t$,$t$Registrar um problema (Ocorrência)$t$,$t$registrar um problema (ocorrência)$t$,$t$No cartão do pedido, toque em “⚠️ Ocorrência”.
Escolha o tipo, descreva o que aconteceu e confirme.
Ela aparece na aba "🔔 Avisos" do Assistente e você pode tratar direto pelo botão "Tratar".$t$,array['Operador'],true,'lista',21,$t$$t$),
($t$man-garcom-01-entrar-sair-e-status$t$,$t$Entrar, sair e status$t$,$t$entrar, sair e status$t$,$t$Digite Login e Senha e toque em “Entrar”.
Olhe o status no topo: 🟢 Online = tudo certo · 🟡 Sincronizando = aguarde · 🔴 Sem conexão = veja “E se der errado?” · 🟠 Contingência = o servidor está lento ou fora do ar e o app usa a reserva. Toque na bolinha colorida do topo para ver o estado do Supabase, da planilha principal e da contingência.
Para sair, toque em “Sair” no topo. Para trocar a sua senha, toque em “🔑 Senha” (precisa da senha atual e de ao menos 8 caracteres).
Suas abas: Início, Atendimento, Pedidos (com Retiradas, Entregas e Mesas) e Clientes. Um ponto azul numa aba avisa que há algo novo.$t$,array['Garçom'],true,'lista',1,$t$“Login ou senha incorretos”: confira os dados. Se esqueceu a senha, só o Administrador pode redefinir. “Sua sessão expirou”: entre de novo; o que você estava digitando pode se perder. “Muitas tentativas erradas”: depois de 5 erros o login fica bloqueado por 10 minutos, contados a partir do primeiro erro. Espere e tente de novo, sem insistir.$t$),
($t$man-garcom-02-buscar-no-topo$t$,$t$Buscar (🔍 no topo)$t$,$t$buscar (🔍 no topo)$t$,$t$Toque na lupa 🔍 no topo e digite o nome do cliente, o número do pedido ou o nome de um produto. Você não vê valores nem telefone dos pedidos.$t$,array['Garçom'],true,'lista',2,$t$$t$),
($t$man-garcom-03-lancar-pedido-de-uma-mesa$t$,$t$Lançar pedido de uma mesa$t$,$t$lançar pedido de uma mesa$t$,$t$Aba Caixa → etapa "1. Cliente" → escolha a mesa. Se estiver Livre, toque em "Abrir mesa".
Vá em "2. Itens", toque nos itens e escolha os adicionais.
Toque em "Lançar na mesa (enviar à cozinha)". Repita quantas vezes o cliente pedir mais.$t$,array['Garçom'],true,'lista',3,$t$"A mesa N está … — não aceita novos itens": já está aguardando fechamento. "Esta mesa está sob responsabilidade de outro garçom": a mesa é de quem a abriu; peça ao Caixa. Você lança pedido de mesa, sem desconto e sem receber pagamento.$t$),
($t$man-garcom-04-pedir-a-conta$t$,$t$Pedir a conta$t$,$t$pedir a conta$t$,$t$Caixa → escolha a mesa (ou toque em "🍽️ Mesas").
Toque em "Pedir fechamento" e confirme.
A mesa passa para "Aguardando fechamento". O Caixa recebe — ou você mesmo, com "💳 Receber conta".$t$,array['Garçom'],true,'lista',4,$t$Só dá para pedir fechamento de mesa "Ocupada".$t$),
($t$man-garcom-05-cliente-pedindo-pela-mesa-qr-code$t$,$t$Cliente pedindo pela mesa (QR Code)$t$,$t$cliente pedindo pela mesa (qr code)$t$,$t$O cliente pode pedir pelo celular. Quem aceita o pedido é o Caixa.
Se ele tocar em "Chamar garçom", a mesa aparece em 🍽️ Mesas com 🔔 e o aparelho avisa.
Depois de atender, toque em ✔ Atendido.$t$,array['Garçom'],true,'lista',5,$t$Se a mesa pedir a conta, ela vira "Pediu a conta".$t$),
($t$man-garcom-06-receber-a-conta-garcom$t$,$t$Receber a conta (garçom)$t$,$t$receber a conta (garçom)$t$,$t$Toque em "🍽️ Mesas" e ache a sua mesa.
Toque em "💳 Receber conta", confira o total e escolha a forma.
Para dividir, marque "Dividir em duas formas".
Confirme. A mesa fica livre e o valor entra no caixa.$t$,array['Garçom'],true,'lista',6,$t$"O caixa está fechado": peça ao caixa para abrir. "Esta mesa não está sob a sua responsabilidade": só quem abriu a mesa recebe.$t$),
($t$man-garcom-07-acompanhar-e-servir$t$,$t$Acompanhar e servir$t$,$t$acompanhar e servir$t$,$t$Aba Pedidos: veja o andamento de cada pedido. Para imprimir o pedido, toque em "🖨️ Imprimir pedido da mesa" no cartão (aparece depois que o pedido é aceito).
Quando estiver "Pronta", leve à mesa e toque em "Marcar como “Servida”".$t$,array['Garçom'],true,'lista',7,$t$$t$),
($t$man-garcom-08-aviso-de-pedido-pronto$t$,$t$Aviso de pedido pronto$t$,$t$aviso de pedido pronto$t$,$t$Na primeira vez, toque em "🔔 Ativar avisos e som".
Quando um pedido das SUAS mesas ficar "Pronta", o aparelho toca, vibra e o título da aba mostra "Pedido pronto".
A checagem roda mesmo com o app em segundo plano.$t$,array['Garçom'],true,'lista',8,$t$$t$),
($t$man-garcom-09-clientes$t$,$t$Clientes$t$,$t$clientes$t$,$t$Aba Clientes → "+ Novo cliente".
Só nome e telefone são obrigatórios.$t$,array['Garçom'],true,'lista',9,$t$$t$),
($t$man-garcom-10-registrar-um-problema-ocorrencia$t$,$t$Registrar um problema (Ocorrência)$t$,$t$registrar um problema (ocorrência)$t$,$t$No cartão do pedido, toque em “⚠️ Ocorrência”.
Escolha o tipo, descreva o que aconteceu e confirme.
O Administrador e o Operador são avisados e resolvem.$t$,array['Garçom'],true,'lista',10,$t$$t$),
($t$man-cozinha-01-entrar-sair-e-status$t$,$t$Entrar, sair e status$t$,$t$entrar, sair e status$t$,$t$Digite Login e Senha e toque em “Entrar”.
Olhe o status no topo: 🟢 Online = tudo certo · 🟡 Sincronizando = aguarde · 🔴 Sem conexão = veja “E se der errado?” · 🟠 Contingência = o servidor está lento ou fora do ar e o app usa a reserva. Toque na bolinha colorida do topo para ver o estado do Supabase, da planilha principal e da contingência.
Para sair, toque em “Sair” no topo. Para trocar a sua senha, toque em “🔑 Senha” (precisa da senha atual e de ao menos 8 caracteres).
Suas abas: Início, Cozinha (os pedidos) e Notificações. Um ponto azul numa aba avisa que há algo novo.$t$,array['Cozinha'],true,'lista',1,$t$“Login ou senha incorretos”: confira os dados. Se esqueceu a senha, só o Administrador pode redefinir. “Sua sessão expirou”: entre de novo; o que você estava digitando pode se perder. “Muitas tentativas erradas”: depois de 5 erros o login fica bloqueado por 10 minutos, contados a partir do primeiro erro. Espere e tente de novo, sem insistir.$t$),
($t$man-cozinha-02-buscar-no-topo$t$,$t$Buscar (🔍 no topo)$t$,$t$buscar (🔍 no topo)$t$,$t$Toque na lupa 🔍 no topo e digite o número do pedido, o nome do cliente ou o nome de um produto para achar um pedido rápido.$t$,array['Cozinha'],true,'lista',2,$t$$t$),
($t$man-cozinha-03-preparar-os-pedidos$t$,$t$Preparar os pedidos$t$,$t$preparar os pedidos$t$,$t$Aba Pedidos: três colunas (Novos, Em preparo, Prontos) com itens, adicionais e observações.
Observação do cliente em um item aparece em destaque com 📝 abaixo do item.
Para imprimir: "🖨️ Comanda" no pedido ou "🖨️ Imprimir novos". Marque "Imprimir sozinho quando chegar pedido" para imprimir automático (o navegador precisa estar em modo quiosque de impressão).
No Início, "🔊 Testar som" confere se o celular toca e "🔔 Ativar avisos" libera notificações.
Pedido novo chega com beep e piscada (o sistema confere a cada poucos segundos com o app aberto e online).
Toque em "▶️ Iniciar preparo" (no pedido do Cardápio: "Aceitar e iniciar preparo").
Terminou? Toque em "✅ Pronto".
A comanda impressa é única: nas entregas traz o endereço, a referência, o telefone e o valor a cobrar. Grampeie no pedido e ele já segue para o entregador.
No fim da tela, "📜 Concluídos neste turno" mostra o que já saiu (retirado, entregue ou servido), com o horário. A lista zera quando o caixa fecha.$t$,array['Cozinha'],true,'lista',3,$t$Sem beep: toque em "🔊 Testar som" no Início, aumente o volume de mídia e tire o modo silencioso. O sistema mantém a tela ligada enquanto o app está aberto. Se aparecer "⚠️ A tela NÃO está sendo mantida ligada", toque em "📱 Manter a tela ligada".$t$),
($t$man-cozinha-04-confirmar-impressao-da-comanda$t$,$t$Confirmar impressão da comanda$t$,$t$confirmar impressão da comanda$t$,$t$Depois de mandar imprimir, fica um botão discreto "🔁 Não saiu? Reimprimir" (some sozinho em 10 min). Ninguém precisa confirmar quando saiu certo.
🔁 Não saiu? Reimprimir: o sistema tira o pedido de "impressos" e manda de novo.
✖ Saiu, ocultar: esconde o botão.$t$,array['Cozinha'],true,'lista',4,$t$$t$),
($t$man-cozinha-05-pedido-alterado-depois-de-impresso$t$,$t$Pedido alterado depois de impresso$t$,$t$pedido alterado depois de impresso$t$,$t$O aparelho guarda uma "foto" da comanda quando você imprime ou quando o pedido aparece na tela.
Se um Admin/Operador editar o pedido, a foto deixa de bater. O cartão ganha faixa vermelha "PEDIDO ALTERADO" e toca dois bipes uma vez.
Para resolver: "🖨️ Reimprimir comanda atualizada" ou "👍 Ciente".$t$,array['Cozinha'],true,'lista',5,$t$$t$),
($t$man-cozinha-06-registrar-um-problema-ocorrencia$t$,$t$Registrar um problema (Ocorrência)$t$,$t$registrar um problema (ocorrência)$t$,$t$No cartão do pedido, toque em “⚠️ Ocorrência”.
Escolha o tipo, descreva o que aconteceu e confirme.
O Administrador e o Operador são avisados. Use para falta de ingrediente ou pedido que não pode ser produzido.$t$,array['Cozinha'],true,'lista',6,$t$$t$),
($t$man-cozinha-07-notificacoes$t$,$t$Notificações$t$,$t$notificações$t$,$t$Mural de avisos. Você só vê os que o Administrador liberou para a Cozinha.$t$,array['Cozinha'],true,'lista',7,$t$$t$),
($t$man-entregador-01-entrar-sair-e-status$t$,$t$Entrar, sair e status$t$,$t$entrar, sair e status$t$,$t$Digite Login e Senha e toque em “Entrar”.
Olhe o status no topo: 🟢 Online = tudo certo · 🟡 Sincronizando = aguarde · 🔴 Sem conexão = veja “E se der errado?” · 🟠 Contingência = o servidor está lento ou fora do ar e o app usa a reserva. Toque na bolinha colorida do topo para ver o estado do Supabase, da planilha principal e da contingência.
Para sair, toque em “Sair” no topo. Para trocar a sua senha, toque em “🔑 Senha” (precisa da senha atual e de ao menos 8 caracteres).
Suas abas: Início, Minhas entregas e Meus ganhos. Um ponto azul numa aba avisa que há algo novo.$t$,array['Entregador'],true,'lista',1,$t$“Login ou senha incorretos”: confira os dados. Se esqueceu a senha, só o Administrador pode redefinir. “Sua sessão expirou”: entre de novo; o que você estava digitando pode se perder. “Muitas tentativas erradas”: depois de 5 erros o login fica bloqueado por 10 minutos, contados a partir do primeiro erro. Espere e tente de novo, sem insistir.$t$),
($t$man-entregador-02-fazer-uma-entrega$t$,$t$Fazer uma entrega$t$,$t$fazer uma entrega$t$,$t$Aba Minhas entregas: aparecem só as suas. Uma nova toca um aviso sonoro.
O cartão mostra itens, endereço, referência, telefone, total, taxa e "📍 Ver no Maps".
Quem marca o pedido como "Pronta" é a Cozinha. Quando pegar o pedido (status "Pronta"), toque em "Marcar como “Saiu para entrega”". Nesse momento o app começa a enviar sua localização.
Ao entregar, toque em "✅ Já entreguei". O envio de localização para sozinho.
Se o cartão diz "A receber", cobre o valor do cliente; quem registra o recebimento é o Caixa.$t$,array['Entregador'],true,'lista',2,$t$Não aparece nada: ainda não atribuíram entrega a você. Avise o Caixa. Pedido "aguardando aceite": o botão só aparece depois que o Caixa aceitar.$t$),
($t$man-entregador-03-aviso-de-entrega-nova$t$,$t$Aviso de entrega nova$t$,$t$aviso de entrega nova$t$,$t$Na primeira vez, toque em "🔔 Ativar avisos e som" (canto da tela).
Quando o Caixa atribuir uma entrega, o aparelho toca, vibra e a aba mostra "Nova entrega".
A checagem roda com o app aberto, mesmo em segundo plano.$t$,array['Entregador'],true,'lista',3,$t$$t$),
($t$man-entregador-04-localizacao-sua-privacidade$t$,$t$Localização (sua privacidade)$t$,$t$localização (sua privacidade)$t$,$t$O envio só liga quando você tem entrega em "Saiu para entrega" — não fica rodando o dia inteiro.
Não guarda histórico: a posição é atualizada em cima da anterior e o banco limpa ao sair do status.
Precisa do GPS permitido no navegador. Se negar, a entrega continua normal; só o mapa do restaurante fica sem sua posição.
Ao marcar "Já entreguei", o envio para automaticamente.$t$,array['Entregador'],true,'lista',4,$t$$t$),
($t$man-entregador-05-meu-dia$t$,$t$Meu dia$t$,$t$meu dia$t$,$t$Em Minhas entregas, "💰 Meu dia" mostra suas entregas de hoje, as taxas e a ajuda diária.
O total previsto é taxas + ajuda diária (uma vez por dia). O acerto oficial é feito pelo Administrador.$t$,array['Entregador'],true,'lista',5,$t$$t$),
($t$man-entregador-06-registrar-um-problema-ocorrencia$t$,$t$Registrar um problema (Ocorrência)$t$,$t$registrar um problema (ocorrência)$t$,$t$No cartão do pedido, toque em “⚠️ Ocorrência”.
Escolha o tipo, descreva o que aconteceu e confirme.
O Administrador e o Operador são avisados. Use para cliente ausente, endereço errado ou problema na entrega.$t$,array['Entregador'],true,'lista',6,$t$$t$)
on conflict (slug) do nothing;
