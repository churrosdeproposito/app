#!/usr/bin/env python3
"""Verificação antes de publicar. Uso: python3 verificar.py SUBIR-NO-GITHUB
Falha (código 1) se: arquivo citado no index.html não existe; ?v= desatualizado; sw.js fora de sincronia;
erro de sintaxe em algum .js; chave secreta no código; charset ausente."""
import re,os,sys,hashlib,subprocess,glob
p=sys.argv[1] if len(sys.argv)>1 else '.'
erros=[];ok=[]
H=open(os.path.join(p,'index.html'),encoding='utf-8').read()
refs=re.findall(r'(?:src|href)="((?:app|estilo)-[^"?]+\.(?:js|css))\?v=([0-9a-f]{8})"',H)
for nome,v in refs:
    f=os.path.join(p,nome)
    if not os.path.exists(f): erros.append('falta arquivo: '+nome); continue
    h=hashlib.sha1(open(f,encoding='utf-8',newline='').read().encode('utf-8')).hexdigest()[:8]
    if h!=v: erros.append('?v= desatualizado (rode selar.py): '+nome)
ok.append('%d arquivos citados no index.html'%len(refs))
for f in glob.glob(os.path.join(p,'app-*.js'))+[os.path.join(p,'sw.js')]:
    r=subprocess.run(['node','--check',f],capture_output=True,text=True)
    if r.returncode: erros.append('sintaxe: %s %s'%(os.path.basename(f),r.stderr.strip().splitlines()[0] if r.stderr else ''))
sw=open(os.path.join(p,'sw.js'),encoding='utf-8').read()
lista=re.search(r'/\*LISTA-INICIO\*/(.*?)/\*LISTA-FIM\*/',sw,re.S).group(1)
if sorted(re.findall(r"'([^']+)'",lista))!=sorted('%s?v=%s'%r for r in refs): erros.append('LISTA do sw.js diferente do index.html (rode selar.py)')
for f in glob.glob(os.path.join(p,'*.js'))+glob.glob(os.path.join(p,'*.html')):
    t=open(f,encoding='utf-8').read()
    if re.search(r'sb_secret_|service_role\s*[:=]\s*[\'"]|AIza[0-9A-Za-z_-]{30,}|gsk_[A-Za-z0-9]{20,}|nvapi-[A-Za-z0-9]{10,}',t): erros.append('possível segredo em '+os.path.basename(f))
for f in glob.glob(os.path.join(p,'estilo-*.css')):
    if not open(f,encoding='utf-8').read().startswith('@charset "utf-8";'): erros.append('falta @charset em '+os.path.basename(f))
for m in re.finditer(r'<script[^>]*src="app-[^>]*>',H):
    if 'charset="utf-8"' not in m.group(0): erros.append('script sem charset: '+m.group(0)[:60])
for e in erros: print('FALHOU:',e)
for o in ok: print('ok:',o)
print('RESULTADO:','REPROVADO' if erros else 'APROVADO'); sys.exit(1 if erros else 0)
