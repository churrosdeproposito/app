# Notas para o Claude (Churros de Propósito)
Mesma estrutura do Texas: `SUBIR-NO-GITHUB/` com index.html (só telas) + `app-NN-*.js` + `estilo-NN-*.css` soltos, sem subpastas.
- Editar o código no arquivo do assunto; não recriar o monólito. Ordem de carregamento = ordem das tags do index.html.
- Ao terminar: `python3 _FERRAMENTAS-E-BACKUP/selar.py SUBIR-NO-GITHUB` e `python3 _FERRAMENTAS-E-BACKUP/verificar.py SUBIR-NO-GITHUB` (APROVADO). Subir o SHELL do sw.js (`churros-shell-vNN`).
- Neutro de Texas: sem mascote, sem 🍔; WhatsApp na constante `WHATSAPP_DO_RESTAURANTE_` (app-01); tema Churros no fim do estilo-01-base.css (antes da CAMADA FUNCIONAL PROTEGIDA, que fica por último).
- Chaves de storage `restaurante*`/`rst*`; domínio de login `@usuarios.restaurante.app`; tópico realtime `realtime:restaurante-pedidos`.
- Zip sempre SEM compressão (empacotar.py) e com CONFERIR-TAMANHOS.txt. Não pôr zip dentro de zip.
- O conector do Supabase recusa DELETE/DROP e reescritas de texto: esses vão num único SQL para o usuário rodar.
- Supabase do Churros: projeto ljipjjzjjnzedcuksmon.
