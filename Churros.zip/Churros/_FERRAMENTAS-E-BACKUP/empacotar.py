#!/usr/bin/env python3
"""Gera ../Churros.zip SEM compressão (o extrator do celular zerava arquivos de zips comprimidos)
e a lista CONFERIR-TAMANHOS.txt. Uso (na pasta acima de 'Churros'): python3 "Churros/_FERRAMENTAS-E-BACKUP/empacotar.py"."""
import os, zipfile, time, sys
raiz = 'Churros'; pasta = os.path.join(raiz, 'SUBIR-NO-GITHUB')
linhas = ['TAMANHO CERTO DE CADA ARQUIVO DA PASTA SUBIR-NO-GITHUB', '(nenhum pode estar com 0 B; confira antes de subir no GitHub)', '']
for n in sorted(os.listdir(pasta)):
    s = os.path.getsize(os.path.join(pasta, n))
    linhas.append(f"{n}  ->  {s/1024:.2f} KB" if s >= 1024 else f"{n}  ->  {s} B")
open(os.path.join(raiz, 'CONFERIR-TAMANHOS.txt'), 'w', encoding='utf-8').write('\n'.join(linhas) + '\n')
vazios = []
if os.path.exists(raiz + '.zip'): os.remove(raiz + '.zip')
with zipfile.ZipFile(raiz + '.zip', 'w', compression=zipfile.ZIP_STORED) as z:
    for d, _, fs in os.walk(raiz):
        for f in sorted(fs):
            p = os.path.join(d, f)
            if os.path.getsize(p) == 0: vazios.append(p)
            zi = zipfile.ZipInfo(p, date_time=time.localtime(os.path.getmtime(p))[:6]); zi.external_attr = 0o644 << 16
            z.writestr(zi, open(p, 'rb').read())
z = zipfile.ZipFile(raiz + '.zip')
ruins = z.testzip(); zerados = [i.filename for i in z.infolist() if i.file_size == 0]
print('arquivos:', len(z.infolist()), '| vazios na origem:', vazios, '| zerados no zip:', zerados, '| teste:', 'ok' if ruins is None else ruins)
sys.exit(1 if (vazios or zerados or ruins) else 0)
