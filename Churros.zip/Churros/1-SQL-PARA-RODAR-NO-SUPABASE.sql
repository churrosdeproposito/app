-- =====================================================================
-- CHURROS DE PROPÓSITO — o ÚNICO SQL que falta rodar no Supabase (11/10/2026)
-- Tudo o mais das melhorias do Texas já foi aplicado no banco por mim.
-- Aqui está só o que o conector do Supabase recusou (apagar dados/objetos e reescrever textos de ajuda).
-- Como rodar: Supabase → SQL Editor → New query → cole TUDO → Run. Pode rodar mais de uma vez sem problema.
-- Se o Supabase perguntar "Run this query?" (por causa dos DELETE/DROP), confirme.
-- =====================================================================

-- ---------- 1) Bebida e item comprado pronto não oferecem adicionais ----------
delete from produto_adicionais pa using produtos p
 where p.id = pa.produto_id and p.estoque_proprio_ingrediente_id is not null;

-- ---------- 2) Sobras que ninguém mais usa (o sistema novo não chama mais estas funções/tabelas) ----------
drop function if exists public.ia_codigo_catalogo();
drop function if exists public.ia_codigo_faltantes(text, jsonb);
drop function if exists public.ia_codigo_gravar(text, text, jsonb);
drop function if exists public.ia_codigo_registrar_versao(text, text, jsonb);
drop table if exists public.codigo_snapshots, public.codigo_versoes, public.codigo_analises, public.ia_relatorio_codigo;
drop function if exists public.api_cancelar_brinde(jsonb);
drop function if exists public.api_push_cliente_cancelar(jsonb);
drop function if exists public.api_editar_cupom(jsonb);
drop table if exists public.precos_backup_20261009;

-- ---------- 3) Textos da ajuda da IA (o conector recusou estes) ----------
update public.ai_ajuda set passos = replace(replace(passos,
  'Financeiro: mostra quanto falta receber do iFood (pedidos pagos no app ainda sem repasse), os repasses recebidos e a comissão real.',
  'Financeiro: mostra quanto falta receber do iFood (pedidos pagos no app ainda sem repasse, já sem a comissão), os repasses recebidos e a comissão real. Comissão: cadastre o % do iFood em Operação → Pagamentos, forma "iFood"; ela entra nas taxas de cada pedido e é trocada pela comissão real quando o repasse chega.'),
  'Relatório por canal: vendas, ticket, margem e cancelamentos de balcão, cardápio e iFood.',
  'Relatório por canal: vendas, ticket, margem (já sem custo, taxas e comissão e imposto estimado) e cancelamentos de balcão, cardápio e iFood.'),
  palavras_chave = palavras_chave || ' margem imposto', atualizado_em = now()
 where slug = 'man-admin-105-ifood-inteligencia' and passos not like '%já sem a comissão%';

update public.ai_ajuda set passos = replace(passos,
  'Com a nota fiscal ligada, o resultado do período (DRE) passa a mostrar a linha "Impostos sobre vendas (estimado)". Desligada, nada muda.',
  'A alíquota dos dados fiscais é a padrão do imposto estimado; a de cada mês fica em Painel → Relatórios, cartão DRE (veja "Imposto sobre vendas"). O imposto aparece no resultado com ou sem a nota fiscal ligada.'), atualizado_em = now()
 where slug = 'man-admin-106-fiscal-cadastro' and passos like '%Desligada, nada muda.%';

update ai_ajuda set passos = replace(passos,
    'Cadastre o fornecedor, depois registre a compra: itens do estoque (ou "outro item"), quantidade, unidade e o valor total pago por item.',
    'Cadastre o fornecedor e registre a compra: em "O que você comprou?" digite e toque no ingrediente ou bebida da lista (aí dá entrada no estoque); texto fora da lista vira só despesa (aviso laranja). Informe quantidade, unidade e valor total. Bebida em fardo: "Embalagens" × "Unidades em cada" (ex.: 2 × 12 = 24). A compra recebida atualiza também o custo dos produtos.') || E'\nAo marcar um pedido de compra como recebido, escolha "✅ Já paguei" ou "🕒 Vou pagar depois" (aí aparece o calendário do vencimento).',
  palavras_chave = coalesce(palavras_chave, '') || ' fardo embalagens unidades em cada não entra no estoque aviso laranja digitar item compra bebida', atualizado_em = now()
 where slug = 'man-admin-93-compras-fornecedores' and position('O que você comprou?' in passos) = 0 and passos not like '%Vou pagar depois%';

update ai_ajuda set
  palavras_chave = 'cadastrar produto novo produto receita ficha técnica ingrediente custo margem preparado aqui comprado pronto sem controle bebida estoque próprio copiar receita criar ingrediente gramas kg litro ml preços em lote paguei cadastro incompleto combo custo automático',
  passos = E'Administrador → Catálogo → Produtos → "+ Novo produto". Preencha nome, categoria, preço de venda e, se quiser, foto e descrição.\nEm "Como é feito?" escolha: 🍳 Preparado aqui (pratos, porções), 🥤 Comprado pronto (bebidas, sobremesa embalada) ou ✍️ Sem controle.\nPreparado aqui: digite o ingrediente, toque nele e diga quanto vai em cada um (kg/litro pedem gramas/ml). Não existe? Toque em "+ criar" ali mesmo. Use "📋 Copiar receita de outro produto" e só ajuste. O custo aparece sozinho.\nComprado pronto: "Paguei R$ __ por __ unidades" (ex.: 30 por 12 = R$ 2,50 por lata), quanto tem agora e o mínimo. Cada venda baixa 1 do estoque.\nSem controle: digite o custo se souber.\nEm "⚙️ Mais opções": preço próprio do iFood, adicionais, destaque e prêmio.\nIngredientes: Catálogo → Estoque → "+ Novo ingrediente" (nome, como compra, "Paguei R$ __ por __") ou "💲 Preços em lote" para vários de uma vez.\nProduto novo já vem com os adicionais que os outros produtos da mesma categoria têm ("Comprado pronto", como bebida, vem sem nenhum). Desmarque o que não vale.',
  comuns = 'O custo dos produtos e combos se atualiza sozinho quando o preço de um ingrediente muda (edição, lote ou compra recebida); combo = soma dos produtos. Trocar kg↔g ou l↔ml converte as receitas; trocar "un"↔kg não converte e o sistema avisa quais receitas revisar. O Estoque tem as abas Ingredientes e Bebidas e itens prontos; bebidas não aparecem na receita. "Cadastro incompleto" mostra produtos sem custo e ingredientes sem preço. Cada venda baixa o estoque pela receita; ingrediente no mínimo gera aviso. Bebida e item comprado pronto não têm adicionais.'
 where slug = 'man-admin-04-cadastrar-produtos-e-estoque';

update ai_ajuda set
  palavras_chave = 'saúde sistema conexão servidores backup conferência vendas tarefas automáticas bolinha verde vermelha',
  passos = E'A "Saúde do sistema" fica dentro de "Conexão e servidores": toque na bolinha colorida do topo.\nLá aparecem os servidores e, logo abaixo, cada item: cópia para a planilha, backup (diário às 04:00), cópia no Drive, conferência diária de vendas, tarefas automáticas e Assistente.\nA própria bolinha do topo muda de cor: verde = tudo certo, amarela = atenção, rosa = precisa de cuidado (se a conexão cair, ela fica vermelha ou laranja). Amarelo pede atenção; vermelho pede ação (ex.: backup com mais de 48 h ou vendas diferentes entre Supabase e planilha).\nDesenvolvedor: o botão "Simular queda (treino)" fica em "Conexão e servidores" e finge a queda só neste aparelho. "Encerrar simulação" volta ao normal.',
  comuns = 'Só Admin e Desenvolvedor veem a Saúde do sistema.'
 where slug = 'man-admin-97-saude-sistema';
