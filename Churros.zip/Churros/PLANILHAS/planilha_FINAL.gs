/**
 * CHURROS DE PROPÓSITO — PLANILHA PRINCIPAL (versão enxuta, 11/10/2026)
 *
 * O sistema hoje roda no Supabase. Esta planilha ficou só com o que ainda é dela:
 *   - abas SB_<tabela>: cópia automática do cardápio, clientes e vendas (chega pelo Supabase a cada 2 min);
 *   - abas Arquivo_*: vendas e caixas antigos que saíram do Supabase para liberar espaço (os relatórios leem daqui);
 *   - Log e Auditoria;
 *   - fotos e cópias de backup no Google Drive desta conta;
 *   - o espelho da planilha de contingência (o Supabase pede a cada 10 min e completo às 3h).
 * Quem chama esta planilha é só o Supabase (com a chave SB_CHAVE_SERVIDOR_PADRAO_ abaixo, ou a propriedade SB_CHAVE_SERVIDOR).
 *
 * COMO ATUALIZAR: Extensões > Apps Script > apague tudo e cole este arquivo > Salvar >
 *   Implantar > Gerenciar implantações > lápis (editar) > Versão: "Nova versão" > Implantar. O endereço /exec continua o mesmo.
 * Os gatilhos (acionadores) do sistema antigo se apagam sozinhos na primeira chamada depois da atualização.
 * Para apagar as abas antigas: escolha "limparAbasAntigas" na lista de funções e toque em Executar (ela faz uma cópia da planilha antes).
 *
 * PLANILHA NOVA (outro restaurante): cole o arquivo, rode "configurarIdPlanilha" uma vez e depois "configurarContingencia"
 *   (se houver contingência). Implantar > Nova implantação > App da Web > Executar como "Eu" > Acesso "Qualquer pessoa".
 *   No Supabase: SHEETS_MAIN_URL = endereço /exec e PRINCIPAL_CHAVE_SERVIDOR = a chave SB_CHAVE_SERVIDOR_PADRAO_.
 */

const FUSO         = 'America/Sao_Paulo';

/* Quem fez a ação (vai para o Log e a Auditoria). Nas chamadas do Supabase ficam vazios. */
let USUARIO_ATUAL = '';
let NIVEL_ATUAL = '';
let APARELHO_ATUAL = ''; // BLOCO 4.2/4.5: "aparelho xxxxxxxx · Chrome · Android" da sessão (o Apps Script não expõe IP)
let AUTORIZADOR_ATUAL = '';

/* ---------- CONTINGÊNCIA (Item 81) ----------
   API separada, numa conta Google diferente, que serve de plano B: espelho de
   leitura (cardápio/produtos/clientes) + fila de vendas feitas enquanto esta
   planilha estiver fora do ar. */
const CONTINGENCIA_API_URL = 'https://script.google.com/macros/s/AKfycbx8kLJ2U-UMDinpcDCJt_iaORcA9IH3dSw3JQf418zlcQ8ti1H85w2fYHnNgA7ZxZtg/exec';
/* SEGURANÇA: as chaves da contingência NÃO ficam no código. Cadastre em Configurações do projeto ->
   Propriedades do script: CONTINGENCIA_CHAVE_SERVIDOR (só esta planilha usa) e CONTINGENCIA_CHAVE_INTERNA
   (entregue só a Admin/Operador logados). Os valores saem da função gerarChaves() do script da contingência. */
function chaveContingencia_(nome) {
  const v = PropertiesService.getScriptProperties().getProperty(nome);
  if (!v) throw new Error('Chave da contingência não configurada (' + nome + '). Veja Propriedades do script.');
  return v;
}

/* CONFIGURAÇÃO RÁPIDA DA CONTINGÊNCIA — rode UMA vez no editor (menu de funções -> configurarContingencia -> Executar).
   Grava as duas chaves nas Propriedades do script (onde o sistema as lê) e já roda a conferência.
   Depois de rodar com sucesso, APAGUE os valores abaixo (deixe '') para as chaves não ficarem escritas no código. */
function configurarContingencia() {
  const SERVIDOR = 'rstsrv-34bd998e58dc4cfc9102858c842033accb1fe646';
  const INTERNA = 'rstint-ee8d294cef014375bb98ba9fdb8d6897479ad9b5';
  PropertiesService.getScriptProperties().setProperties({ CONTINGENCIA_CHAVE_SERVIDOR: SERVIDOR, CONTINGENCIA_CHAVE_INTERNA: INTERNA });
  return conferirChavesContingencia();
}

/* ITEM 16 — conferência das chaves da contingência.
   Rode no editor do Apps Script (menu de funções -> conferirChavesContingencia -> Executar) e veja o "Registro de execução".
   Nunca mostra a chave inteira. */
function conferirChavesContingencia() {
  const p = PropertiesService.getScriptProperties();
  const srv = p.getProperty('CONTINGENCIA_CHAVE_SERVIDOR') || '';
  const int = p.getProperty('CONTINGENCIA_CHAVE_INTERNA') || '';
  const mascara = v => v ? v.slice(0, 7) + '…' + v.slice(-4) + ' (' + v.length + ' caracteres)' : 'AUSENTE';
  const chamar = (chave, action) => {
    try {
      const r = UrlFetchApp.fetch(CONTINGENCIA_API_URL, { method: 'post', contentType: 'application/json', payload: JSON.stringify({ chave: chave, action: action }), muteHttpExceptions: true });
      return JSON.parse(r.getContentText());
    } catch (e) { return { ok: false, message: 'Falha de rede: ' + e.message }; }
  };
  const L = [];
  L.push('CONTINGENCIA_CHAVE_SERVIDOR: ' + mascara(srv) + (srv && srv.indexOf('rstsrv-') !== 0 ? '   ⚠ prefixo inesperado (deveria começar com rstsrv-)' : ''));
  L.push('CONTINGENCIA_CHAVE_INTERNA : ' + mascara(int) + (int && int.indexOf('rstint-') !== 0 ? '   ⚠ prefixo inesperado (deveria começar com rstint-)' : ''));
  if (srv && srv === int) L.push('⚠ SERVIDOR e INTERNA são iguais — devem ser chaves diferentes.');
  if (srv) { const r = chamar(srv, 'listarPendentes'); L.push('Teste SERVIDOR (listarPendentes): ' + (r.ok ? 'OK — a contingência aceitou a chave' : 'FALHOU — ' + (r.message || 'sem resposta'))); }
  if (int) {
    const r1 = chamar(int, 'getEspelhoInterno'); L.push('Teste INTERNA (getEspelhoInterno): ' + (r1.ok ? 'OK — a contingência aceitou a chave' : 'FALHOU — ' + (r1.message || 'sem resposta')));
    const r2 = chamar(int, 'listarPendentes'); L.push('Teste INTERNA não pode listar pendentes: ' + (r2.ok ? '⚠ ela aceitou uma ação só de servidor — confira se não é a mesma chave' : 'OK (negado, como deve ser)'));
  }
  L.push('Chave PÚBLICA: fica no index.html (constante CONTINGENCIA_CHAVE_PUBLICA) e deve ser igual à CHAVE_PUBLICA do projeto da contingência.');
  Logger.log(L.join('\n'));
  return L.join('\n');
}

function responder(obj) { return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON); }
function agora() { return Utilities.formatDate(new Date(), FUSO, 'dd/MM/yyyy HH:mm'); }
let _ssMemo_ = null; // OTIMIZAÇÃO: abre a planilha UMA vez por execução (antes, cada leitura chamava openById de novo)
function ss_() {
  const props = PropertiesService.getScriptProperties();
  let id = props.getProperty('SPREADSHEET_ID');
  if (!id) {
    // Primeira vez rodando: captura o ID enquanto ainda há um contexto vinculado
    // disponível, e guarda pra sempre — depois disso, nunca mais depende de
    // getActiveSpreadsheet() (que falha silenciosamente em Web App e em gatilhos
    // por tempo, já que ali não existe planilha "ativa").
    const ativa = SpreadsheetApp.getActiveSpreadsheet();
    if (!ativa) throw new Error('Não foi possível identificar a planilha na primeira execução. Abra o editor do Apps Script pela própria planilha (Extensões → Apps Script) e rode a função configurarIdPlanilha() uma vez.');
    id = ativa.getId();
    props.setProperty('SPREADSHEET_ID', id);
  }
  if (!_ssMemo_) _ssMemo_ = SpreadsheetApp.openById(id);
  return _ssMemo_;
}
/* Rode esta função uma vez pelo editor do Apps Script (aberto a partir da
   própria planilha) se por algum motivo o ID precisar ser (re)configurado. */
function configurarIdPlanilha() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  PropertiesService.getScriptProperties().setProperty('SPREADSHEET_ID', ss.getId());
  return 'ID da planilha configurado: ' + ss.getId();
}

const ACOES_AUDITADAS_RE = /ajuste p[óo]s-venda|suspens|retomad|desconto|cancelad|editada|estorno|estoque|perda|inventário|usuário|senha|sangria|despesa|forma de pagamento|restaur|backup|acesso negado|preço|fechamento|entregador atribu|login falhou|conta de mesa|qr da mesa/i;
function registrarAuditoria_(acao, detalhes) {
  const ss = ss_();
  let sh = ss.getSheetByName('Auditoria');
  if (!sh) {
    sh = ss.insertSheet('Auditoria');
    sh.appendRow(['Data/Hora', 'Usuário', 'Perfil', 'Ação', 'Detalhes', 'Autorizado por', 'Aparelho']);
    sh.setFrozenRows(1); sh.setTabColor('#5a5a5a');
  }
  if (sh.getLastColumn() < 7) sh.getRange(1, 7).setValue('Aparelho'); // BLOCO 4.2: abas antigas ganham a coluna sozinhas
  sh.appendRow([agora(), USUARIO_ATUAL || '', NIVEL_ATUAL || '', acao, detalhes || '', AUTORIZADOR_ATUAL || '', APARELHO_ATUAL || '']);
}

/* ---------- LOG ---------- */
function registrarLog(acao, telefone, detalhes) {
  const ss = ss_();
  let sh = ss.getSheetByName('Log');
  if (!sh) { sh = ss.insertSheet('Log'); sh.appendRow(['Data/Hora', 'Ação', 'Telefone', 'Detalhes', 'Usuário']); sh.setFrozenRows(1); }
  sh.appendRow([agora(), acao, telefone || '', detalhes || '', USUARIO_ATUAL || '']);
  if (ACOES_AUDITADAS_RE.test(String(acao))) registrarAuditoria_(acao, (telefone ? '[' + telefone + '] ' : '') + (detalhes || ''));
}
function urlFoto_(fotoId) { return fotoId ? ('https://drive.google.com/uc?export=view&id=' + fotoId) : ''; }
/* ---------- FOTOS (Google Drive) ---------- */
function obterPastaFotos_() {
  const props = PropertiesService.getScriptProperties();
  const folderId = props.getProperty('PASTA_FOTOS_ID');
  if (folderId) {
    try { return DriveApp.getFolderById(folderId); } catch (e) { /* pasta foi apagada, recria abaixo */ }
  }
  const raiz = DriveApp.getRootFolder();
  const existentes = raiz.getFoldersByName('Churros de Propósito - Fotos');
  const pasta = existentes.hasNext() ? existentes.next() : raiz.createFolder('Churros de Propósito - Fotos');
  props.setProperty('PASTA_FOTOS_ID', pasta.getId());
  return pasta;
}
function nomeArquivoSeguro_(nome) {
  const base = (nome || 'item').toString().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-zA-Z0-9\-_ ]/g, '').trim().replace(/\s+/g, '-').toLowerCase();
  return (base || 'item');
}
/* Sobe a foto NOVA primeiro; só depois de confirmado que ela foi salva com sucesso
   é que a foto ANTIGA (fotoIdAntigo) é excluída do Drive. Se o upload falhar, a antiga permanece intacta. */
function _uploadFotoSegura(nomeBase, base64Data, mimeType, fotoIdAntigo) {
  if (!base64Data) return { ok: false, message: 'Nenhuma imagem recebida.' };
  try {
    const pasta = obterPastaFotos_();
    const dadosLimpos = base64Data.indexOf(',') >= 0 ? base64Data.split(',').pop() : base64Data;
    const bytes = Utilities.base64Decode(dadosLimpos);
    /* SEGURANÇA (Módulo 3): confere o conteúdo real do arquivo (não confia no tipo informado). Só JPEG/PNG/WEBP até 5 MB —
       impede hospedar HTML, SVG ou executável no Drive do restaurante com link público. */
    if (bytes.length > 5 * 1024 * 1024) return { ok: false, message: 'Imagem grande demais (máximo 5 MB).' };
    const b = bytes;
    const u8 = function (k) { return (b[k] + 256) % 256; };
    let tipoReal = '', ext = '';
    if (u8(0) === 0xFF && u8(1) === 0xD8 && u8(2) === 0xFF) { tipoReal = 'image/jpeg'; ext = '.jpg'; }
    else if (u8(0) === 0x89 && u8(1) === 0x50 && u8(2) === 0x4E && u8(3) === 0x47) { tipoReal = 'image/png'; ext = '.png'; }
    else if (u8(0) === 0x52 && u8(1) === 0x49 && u8(2) === 0x46 && u8(3) === 0x46 && u8(8) === 0x57 && u8(9) === 0x45 && u8(10) === 0x42 && u8(11) === 0x50) { tipoReal = 'image/webp'; ext = '.webp'; }
    if (!tipoReal) return { ok: false, message: 'Arquivo não é uma imagem válida (use JPG, PNG ou WEBP).' };
    const nomeArquivo = nomeArquivoSeguro_(nomeBase) + '-' + Utilities.getUuid().slice(0, 8) + ext;
    const blob = Utilities.newBlob(bytes, tipoReal, nomeArquivo);
    const arquivo = pasta.createFile(blob);
    arquivo.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
    const novoId = arquivo.getId();
    // Só chega aqui se o upload da nova foto deu certo — agora sim pode excluir a antiga.
    if (fotoIdAntigo) { try { DriveApp.getFileById(fotoIdAntigo).setTrashed(true); } catch (e) { /* antiga já não existe, ok */ } }
    return { ok: true, fotoId: novoId, fotoUrl: urlFoto_(novoId) };
  } catch (e) {
    return { ok: false, message: 'Não foi possível salvar a foto: ' + e.message };
  }
}
const ARMAZ_ATENCAO_PCT = 70, ARMAZ_CRITICO_PCT = 90;
function obterPastaBackups_() {
  const props = PropertiesService.getScriptProperties();
  const folderId = props.getProperty('PASTA_BACKUPS_ID');
  if (folderId) { try { return DriveApp.getFolderById(folderId); } catch (e) { /* pasta apagada, recria abaixo */ } }
  const raiz = DriveApp.getRootFolder();
  const existentes = raiz.getFoldersByName('Churros de Propósito - Backups');
  const pasta = existentes.hasNext() ? existentes.next() : raiz.createFolder('Churros de Propósito - Backups');
  props.setProperty('PASTA_BACKUPS_ID', pasta.getId());
  return pasta;
}
/* Google Sheets nativo devolve getSize()=0; o tamanho real é medido pela exportação xlsx (aproximado). */
function tamanhoAproximadoPlanilha_(fileId) {
  try {
    const r = UrlFetchApp.fetch('https://docs.google.com/spreadsheets/d/' + fileId + '/export?format=xlsx',
      { headers: { Authorization: 'Bearer ' + ScriptApp.getOAuthToken() }, muteHttpExceptions: true });
    return r.getResponseCode() === 200 ? r.getBlob().getBytes().length : 0;
  } catch (e) { return 0; }
}
function obterArmazenamentoDrive_() {
  const usado = DriveApp.getStorageUsed(), limite = DriveApp.getStorageLimit();
  const pct = limite > 0 ? Math.round(usado / limite * 1000) / 10 : null;
  const nivel = pct === null ? 'Indisponível' : pct > ARMAZ_CRITICO_PCT ? 'Crítico' : pct >= ARMAZ_ATENCAO_PCT ? 'Atenção' : 'Normal';
  return { usado: usado, limite: limite, livre: limite > 0 ? Math.max(0, limite - usado) : null, percentual: pct, nivel: nivel };
}

/* ---------- ITEM 18: espaço da conta da contingência ---------- */
function obterArmazenamentoContingencia() {
  try {
    const r = chamarContingencia_('getArmazenamento');
    if (!r || !r.ok) return { ok: false, message: (r && r.message) || 'A contingência não respondeu.' };
    return r;
  } catch (e) { return { ok: false, message: 'Não foi possível falar com a contingência: ' + e.message }; }
}

/* ---------- CONTINGÊNCIA — SINCRONIZAÇÃO E RECONCILIAÇÃO (Item 81) ---------- */
function chamarContingencia_(action, extra) {
  const payload = Object.assign({ chave: chaveContingencia_('CONTINGENCIA_CHAVE_SERVIDOR'), action: action }, extra || {});
  const resp = UrlFetchApp.fetch(CONTINGENCIA_API_URL, {
    method: 'post', contentType: 'application/json', payload: JSON.stringify(payload), muteHttpExceptions: true
  });
  return JSON.parse(resp.getContentText());
}

/* ============================================================================
   CHAMADAS DO SUPABASE (Edge Functions sync-fila, planilha-admin, arquivar-antigos, upload-foto, remover-foto,
   sincronizar-fotos, criar-backup e conferir-integridade). Toda chamada traz a chave do servidor.
   ============================================================================ */
/* Chave que a Edge Function envia. Já vem preenchida aqui; se existir a propriedade de script SB_CHAVE_SERVIDOR, ela tem prioridade. */
const SB_CHAVE_SERVIDOR_PADRAO_ = 'rstsb-c4a47f3c7ccd28c44270980f134f524a1824ad04';
const ACOES_SERVIDOR_SB_ = ['syncLote', 'arquivar', 'replicarFotos', 'contarVendasHoje', 'uploadFotoSb', 'excluirFotoSb',
  'sbSincronizarContingencia', 'sbLerArquivo', 'sbLerArquivoCaixa', 'sbGuardarBackup', 'sbChaveLeitura', 'sbArmazenamento', 'sbArmazenamentoContingencia', 'sbChaveContingencia', 'sbListarPendentesContingencia', 'sbMarcarSincronizadoContingencia'];
const ACOES_SEM_TRAVA_SB_ = ['contarVendasHoje', 'sbSincronizarContingencia', 'sbArmazenamento', 'sbArmazenamentoContingencia', 'sbChaveContingencia', 'sbListarPendentesContingencia'];
const SB_FUSO_ = 'America/Sao_Paulo';
const SB_LIMITE_CELULA_ = 40000;

function acaoServidorSb_(action, body) {
  try { removerGatilhosAntigosUmaVez_(false); } catch (eG) {}
  const esperada = PropertiesService.getScriptProperties().getProperty('SB_CHAVE_SERVIDOR') || SB_CHAVE_SERVIDOR_PADRAO_;
  if (!esperada || !sbIgual_(String(body.chave || ''), esperada)) return { ok: false, message: 'Chave inválida.' };
  /* Só leitura (não altera nada): não espera nem segura o lock, para um relatório de mês antigo não travar o envio de vendas e vice-versa. */
  if (action === 'sbLerArquivo' || action === 'sbLerArquivoCaixa') {
    try { return action === 'sbLerArquivo' ? sbLerArquivo_(body.mes) : sbLerArquivoCaixa_(body.mes); }
    catch (e) { return { ok: false, message: 'Erro: ' + String(e && e.message || e).slice(0, 300) }; }
  }
  /* só leitura / demoradas: NÃO seguram a trava das gravações. Antes, abrir o painel de armazenamento
     (que varre o Drive) ou rodar o espelho da contingência fazia o envio de vendas esperar. */
  if (ACOES_SEM_TRAVA_SB_.indexOf(action) !== -1) {
    try {
      if (action === 'contarVendasHoje') return sbContarVendasHoje_(body.data);
      if (action === 'sbSincronizarContingencia') return sbSincronizarContingenciaGuardada_(body.rapido === true);
      if (action === 'sbArmazenamento') return sbObterArmazenamento_();
      if (action === 'sbArmazenamentoContingencia') return obterArmazenamentoContingencia();
      if (action === 'sbChaveContingencia') return sbChaveContingencia_();
      if (action === 'sbListarPendentesContingencia') return sbListarPendentesContingencia_();
    } catch (e) { return { ok: false, message: 'Erro: ' + String(e && e.message || e).slice(0, 300) }; }
  }
  const lock = LockService.getScriptLock();
  try { lock.waitLock(25000); } catch (e) { return { ok: false, ocupado: true, message: 'Planilha ocupada.' }; }
  try {
    if (action === 'syncLote') return sbSyncLote_(body.itens);
    if (action === 'arquivar') return sbArquivar_(body);
    if (action === 'replicarFotos') return sbReplicarFotos_(body.itens);
    if (action === 'uploadFotoSb') return sbUploadFotoSb_(body);
    if (action === 'excluirFotoSb') return sbExcluirFotoSb_(body.ids);
    if (action === 'contarVendasHoje') return sbContarVendasHoje_(body.data);
    if (action === 'sbSincronizarContingencia') return sbSincronizarContingencia_(body.rapido === true);
    if (action === 'sbChaveLeitura') return sbChaveLeitura_(body.renovar === true);
    if (action === 'sbArmazenamento') return sbObterArmazenamento_();
    if (action === 'sbLerArquivo') return sbLerArquivo_(body.mes);
    if (action === 'sbLerArquivoCaixa') return sbLerArquivoCaixa_(body.mes);
    if (action === 'sbGuardarBackup') return sbGuardarBackup_(body);
    if (action === 'sbArmazenamentoContingencia') return obterArmazenamentoContingencia();
    if (action === 'sbChaveContingencia') return sbChaveContingencia_();
    if (action === 'sbListarPendentesContingencia') return sbListarPendentesContingencia_();
    if (action === 'sbMarcarSincronizadoContingencia') return sbMarcarSincronizadoContingencia_(body.ids);
    return { ok: false, message: 'Ação desconhecida.' };
  } catch (e) {
    return { ok: false, message: 'Erro: ' + String(e && e.message || e).slice(0, 300) };
  } finally { try { sbGravarStamps_(); } catch (e) {} lock.releaseLock(); }
}

function sbIgual_(a, b) { // comparação sem atalho por tamanho/posição
  if (a.length !== b.length) return false;
  let d = 0; for (let i = 0; i < a.length; i++) d |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return d === 0;
}

/* Valor → célula. Texto que o Sheets converteria sozinho (datas, números, fórmulas) ganha apóstrofo para ficar texto;
   números de verdade continuam números (evita o problema de "número formatado como texto"). */
function sbCelula_(v) {
  if (v === null || v === undefined) return '';
  if (typeof v === 'number' || typeof v === 'boolean') return v;
  let s = (typeof v === 'object') ? JSON.stringify(v) : String(v);
  if (s.length > SB_LIMITE_CELULA_) s = s.slice(0, SB_LIMITE_CELULA_);
  if (/^[=+\-@]/.test(s) || /^\d{4}-\d{2}-\d{2}/.test(s) || /^[\d.,\s:]+(e\d+)?$/i.test(s)) s = "'" + s;
  return s;
}

function sbAba_(nome) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(nome);
  if (!sh) { sh = ss.insertSheet(nome); sh.getRange(1, 1).setValue('_id'); sh.setFrozenRows(1); }
  return sh;
}

/* marcas de "o que mudou": cada aba SB_ alterada recebe a hora da última alteração.
   O espelho da contingência usa essas marcas para reler e reenviar SÓ o que mudou. Gravadas UMA vez por chamada (sbGravarStamps_). */
let _sbStamps_ = {};
function sbMarcarAlterada_(aba) { if (/^(SB_|Arquivo_)/.test(aba)) _sbStamps_[aba] = Date.now(); }   // Arquivo_* também: o cache de leitura do arquivo usa a marca
function sbLerStamps_() { try { return JSON.parse(PropertiesService.getScriptProperties().getProperty('SB_STAMPS') || '{}') || {}; } catch (e) { return {}; } }
function sbGravarStamps_() {
  const ks = Object.keys(_sbStamps_); if (!ks.length) return;
  try { const m = sbLerStamps_(); ks.forEach(function (k) { m[k] = _sbStamps_[k]; }); PropertiesService.getScriptProperties().setProperty('SB_STAMPS', JSON.stringify(m)); } catch (e) { /* só um acelerador: sem a marca, o próximo espelho completo reenvia tudo */ }
  _sbStamps_ = {};
}
/* Agrupa números de linha em faixas contínuas: [3,4,5,9] -> [[3,3],[9,1]] como [inicio, quantidade]. */
function sbFaixas_(linhas) {
  const o = linhas.slice().sort(function (a, b) { return a - b; }), out = [];
  o.forEach(function (n) { const u = out[out.length - 1]; if (u && n === u[0] + u[1]) u[1]++; else out.push([n, 1]); });
  return out;
}

/* Upsert/remoção por id numa aba. linhas = [{id, dados}], remover = [id]. Devolve {gravadas, removidas}.
   OTIMIZADO: lê a coluna de ids UMA vez; grava linhas vizinhas em um só bloco; apaga linhas em faixas (deleteRows),
   em vez de uma chamada à planilha por linha. O resultado na planilha é idêntico ao da versão anterior. */
function sbUpsert_(nomeAba, linhas, remover) {
  const sh = sbAba_(nomeAba);
  let cab = sh.getLastColumn() ? sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(String) : ['_id'];
  if (!cab.length || cab[0] === '') cab = ['_id'];
  // colunas novas
  const novas = [];
  linhas.forEach(function (l) { Object.keys(l.dados).forEach(function (k) { if (cab.indexOf(k) === -1 && novas.indexOf(k) === -1) novas.push(k); }); });
  if (novas.length) { cab = cab.concat(novas); sh.getRange(1, 1, 1, cab.length).setValues([cab]); }
  const ultima = sh.getLastRow();
  const ids = ultima > 1 ? sh.getRange(2, 1, ultima - 1, 1).getValues().map(function (r) { return String(r[0]).replace(/^'/, ''); }) : [];
  const pos = {}; ids.forEach(function (id, i) { pos[id] = i + 2; });

  const atualizar = [], novasLinhas = [], idxNova = {}; let gravadas = 0;
  linhas.forEach(function (l) {
    const linha = cab.map(function (c, i) { return i === 0 ? sbCelula_(l.id) : (c in l.dados ? sbCelula_(l.dados[c]) : ''); });
    const chave = String(l.id), p = pos[chave];
    if (p > 0) atualizar.push({ p: p, linha: linha });
    else if (idxNova[chave] !== undefined) novasLinhas[idxNova[chave]] = linha;   // mesmo id duas vezes no lote: vale o último
    else { idxNova[chave] = novasLinhas.length; novasLinhas.push(linha); }
    gravadas++;
  });
  // atualizações: linhas vizinhas viram UMA gravação
  if (atualizar.length) {
    atualizar.sort(function (a, b) { return a.p - b.p; });
    let k = 0;
    while (k < atualizar.length) {
      let f = k; while (f + 1 < atualizar.length && atualizar[f + 1].p === atualizar[f].p + 1) f++;
      sh.getRange(atualizar[k].p, 1, f - k + 1, cab.length).setValues(atualizar.slice(k, f + 1).map(function (x) { return x.linha; }));
      k = f + 1;
    }
  }
  if (novasLinhas.length) sh.getRange(sh.getLastRow() + 1, 1, novasLinhas.length, cab.length).setValues(novasLinhas);

  let removidas = 0;
  if (remover && remover.length) {
    const alvo = {}; remover.forEach(function (id) { alvo[String(id)] = true; });
    const apagar = []; ids.forEach(function (id, i) { if (alvo[id]) apagar.push(i + 2); });
    const faixas = sbFaixas_(apagar);
    for (let f = faixas.length - 1; f >= 0; f--) { sh.deleteRows(faixas[f][0], faixas[f][1]); removidas += faixas[f][1]; }   // de baixo para cima: as posições de cima não mudam
  }
  if (gravadas || removidas) sbMarcarAlterada_(nomeAba);
  return { gravadas: gravadas, removidas: removidas };
}

/* Tabelas copiadas para abas SB_: só as que esta planilha usa (espelho da contingência, conferência do dia e arquivo de vendas).
   O banco já só manda estas; se chegar outra (versão antiga do banco), ela é ignorada e conta como recebida. */
const SB_TABELAS_ESPELHO_ = ['categorias', 'produtos', 'produto_precos', 'combos', 'combo_precos', 'combo_itens', 'adicionais', 'produto_adicionais',
  'formas_pagamento', 'sistema', 'clientes', 'vendas', 'itens_venda', 'pagamentos_venda'];

/* itens da fila_sync: {id, tabela, registro_id, operacao, payload}. Só vale o ÚLTIMO estado de cada registro. */
function sbSyncLote_(itens) {
  if (!Array.isArray(itens)) return { ok: false, message: 'Lote inválido.' };
  const ultimo = {}; // tabela|id -> item
  itens.forEach(function (it) { if (it && it.tabela && it.registro_id != null) ultimo[it.tabela + '|' + it.registro_id] = it; });
  const porTabela = {};
  Object.keys(ultimo).forEach(function (k) {
    const it = ultimo[k]; const t = String(it.tabela).replace(/[^a-z0-9_]/gi, '');
    if (!t || SB_TABELAS_ESPELHO_.indexOf(t) === -1) return;
    porTabela[t] = porTabela[t] || { up: [], del: [] };
    if (it.operacao === 'DELETE') porTabela[t].del.push(String(it.registro_id));
    else porTabela[t].up.push({ id: String(it.registro_id), dados: it.payload || {} });
  });
  let total = 0;
  Object.keys(porTabela).forEach(function (t) {
    const r = sbUpsert_('SB_' + t, porTabela[t].up, porTabela[t].del);
    total += r.gravadas + r.removidas;
  });
  return { ok: true, processados: total };
}

/* arquivo permanente. Grava por id (reenvio não duplica), confere e só então tira do espelho. */
function sbArquivar_(b) {
  function pacote(lista, aba, chaveAba) {
    const linhas = (lista || []).map(function (r) {
      if (!r || r.id == null) throw new Error('Linha sem id em ' + aba);
      return { id: String(r.id), dados: r };
    });
    sbUpsert_(aba, linhas, []);
    if (SpreadsheetApp.getActiveSpreadsheet().getSheetByName(chaveAba)) sbUpsert_(chaveAba, [], linhas.map(function (l) { return l.id; })); // sai do espelho "vivo" (sem criar aba que não existe)
    return linhas.length;
  }
  if (b.tipo === 'vendas') {
    const n = pacote(b.vendas, 'Arquivo_Vendas', 'SB_vendas');
    pacote(b.itens, 'Arquivo_Itens', 'SB_itens_venda');
    pacote(b.pagamentos, 'Arquivo_Pagamentos', 'SB_pagamentos_venda');
    return { ok: true, recebidas: n };
  }
  if (b.tipo === 'caixa') {
    const n = pacote(b.caixas, 'Arquivo_Caixa', 'SB_caixa_sessoes');
    pacote(b.sangrias, 'Arquivo_Sangrias', 'SB_sangrias');
    return { ok: true, recebidas: n };
  }
  return { ok: false, message: 'Tipo de arquivamento desconhecido.' };
}

/* fotos. O envio usa _uploadFotoSegura (valida tipo/tamanho) e a cópia para a reserva usa a mesma
   contingência que o app já tinha (chamarContingencia_ 'guardarFoto'): nada de pasta ou conta nova. */
function sbUploadFotoSb_(b) {
  const r = _uploadFotoSegura(b.nomeBase || 'item', b.base64Data, b.mimeType, null);
  if (!r.ok) return r;
  let reserva = '';
  if (b.copiarContingencia) {
    try {
      const bytes = DriveApp.getFileById(r.fotoId).getBlob().getBytes();
      const c = chamarContingencia_('guardarFoto', { idOrigem: r.fotoId, base64: Utilities.base64Encode(bytes) });
      if (c && c.ok) reserva = c.fotoIdReserva;
    } catch (e) { /* a foto principal já está salva; a reserva é copiada depois pelo botão de sincronizar */ }
  }
  return { ok: true, fotoId: r.fotoId, fotoReservaId: reserva };
}
function sbExcluirFotoSb_(ids) {
  (ids || []).forEach(function (id) { try { DriveApp.getFileById(id).setTrashed(true); } catch (e) { /* já não existe */ } });
  return { ok: true };
}
function sbReplicarFotos_(itens) {
  const inicio = Date.now(), resultados = [], falhas = [];
  (itens || []).forEach(function (p) {
    if (Date.now() - inicio > 200000 || !p.foto_id_principal) return;
    try {
      const bytes = DriveApp.getFileById(p.foto_id_principal).getBlob().getBytes();
      if (bytes.length > 5 * 1024 * 1024) { falhas.push(p.id + ': maior que 5 MB'); return; }
      const c = chamarContingencia_('guardarFoto', { idOrigem: p.foto_id_principal, base64: Utilities.base64Encode(bytes) });
      if (c && c.ok) resultados.push({ tipo: p.tipo, id: p.id, foto_id_contingencia: c.fotoIdReserva });
      else falhas.push(p.id + ': ' + ((c && c.message) || 'recusada'));
    } catch (e) { falhas.push(p.id + ': ' + e.message); }
  });
  return { ok: true, resultados: resultados, falhas: falhas, message: falhas.length ? falhas.length + ' foto(s) não copiadas.' : '' };
}

/* vendas confirmadas do dia (horário de Brasília) no espelho. data = 'yyyy-MM-dd'.
   OTIMIZADO: lê só as colunas status e data_hora, de baixo para cima, e para quando passa dos dias que interessam
   (antes lia a aba inteira, todas as colunas). Sem trava: é só leitura. */
function sbContarVendasHoje_(data) {
  const a = sbAbaCab_('SB_vendas');
  if (!a) return { ok: true, total: 0 };
  const iS = a.cab.indexOf('status'), iD = a.cab.indexOf('data_hora');
  if (iS < 0 || iD < 0) return { ok: false, message: 'Colunas status/data_hora não encontradas em SB_vendas.' };
  const corte = Date.parse(String(data) + 'T00:00:00Z') - 3 * 86400000;   // folga de 3 dias: cobre fuso e linhas fora de ordem
  const BLOCO = 1000; let total = 0, fim = a.ultima;
  while (fim >= 2) {
    const ini = Math.max(2, fim - BLOCO + 1), n = fim - ini + 1;
    const st = a.sh.getRange(ini, iS + 1, n, 1).getValues(), dh = a.sh.getRange(ini, iD + 1, n, 1).getValues();
    let todasAntigas = true;
    for (let k = 0; k < n; k++) {
      const d = (dh[k][0] instanceof Date) ? dh[k][0] : new Date(String(dh[k][0]));
      if (isNaN(d.getTime())) { todasAntigas = false; continue; }
      if (d.getTime() >= corte) todasAntigas = false;
      if (String(st[k][0]) === 'Confirmada' && Utilities.formatDate(d, SB_FUSO_, 'yyyy-MM-dd') === data) total++;
    }
    if (todasAntigas) break;
    fim = ini - 1;
  }
  return { ok: true, total: total };
}


/* ============================================================================
   CHURROS DE PROPÓSITO — CONTINGÊNCIA E ARMAZENAMENTO
   (Já faz parte deste arquivo.)
   O espelho da contingência agora é montado a partir das abas SB_<tabela> (o que o Supabase envia),
   e não mais das abas antigas (Produtos, Clientes…), que deixaram de ser atualizadas.
   Chamadas só pela Edge Function "planilha-admin" (chave do servidor); as chaves da contingência
   continuam só nas Propriedades do script.
   ============================================================================ */
function sbLerAba_(nome) {
  const sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(nome);
  if (!sh || sh.getLastRow() < 2 || sh.getLastColumn() < 2) return [];
  const cab = sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(String);
  return sh.getRange(2, 1, sh.getLastRow() - 1, cab.length).getValues().map(function (r) {
    const o = {}; for (let i = 1; i < cab.length; i++) if (cab[i]) o[cab[i]] = r[i]; return o;
  }).filter(function (o) { return o.id !== undefined && String(o.id) !== ''; });
}
function sbJson_(v, padrao) { if (v && typeof v === 'object') return v; try { const o = JSON.parse(String(v || '').replace(/^'/, '')); return o === null ? padrao : o; } catch (e) { return padrao; } }
function sbBool_(v) { return v === true || String(v).toLowerCase() === 'true'; }
function sbNum_(v) { const n = Number(v); return isFinite(n) ? n : 0; }
function sbUrlFoto_(id) { return id ? ('https://drive.google.com/uc?export=view&id=' + id) : ''; }

/* Copia para a contingência só as fotos que ela ainda não tem (ids vêm de SB_produtos / SB_combos). */
function sbSincronizarFotosContingencia_(prods, combos, limiteMs) {
  const inicio = Date.now();
  const res = { mapa: {}, enviadas: 0, faltam: 0, falhas: [], removidas: 0, totalFotos: 0 };
  const ids = {};
  prods.forEach(function (p) { if (p.foto_id_principal) ids[p.foto_id_principal] = true; });
  combos.forEach(function (c) { if (c.foto_id_principal) ids[c.foto_id_principal] = true; });
  const lista = Object.keys(ids); res.totalFotos = lista.length;
  const l = chamarContingencia_('listarFotos');
  if (!l || !l.ok) { res.falhas.push((l && l.message) || 'listarFotos falhou'); return res; }
  res.mapa = l.fotos || {};
  const faltando = lista.filter(function (id) { return !res.mapa[id]; });
  for (let i = 0; i < faltando.length; i++) {
    if (Date.now() - inicio > limiteMs) { res.faltam = faltando.length - i; break; }
    const id = faltando[i];
    try {
      const bytes = DriveApp.getFileById(id).getBlob().getBytes();
      if (bytes.length > 5 * 1024 * 1024) { res.falhas.push(id + ': maior que 5 MB'); continue; }
      const r = chamarContingencia_('guardarFoto', { idOrigem: id, base64: Utilities.base64Encode(bytes) });
      if (r && r.ok) { res.mapa[id] = r.fotoIdReserva; res.enviadas++; } else res.falhas.push(id + ': ' + ((r && r.message) || 'recusada'));
    } catch (e) { res.falhas.push(id + ': ' + e.message); }
  }
  if (!res.faltam && !res.falhas.length && lista.length) { // só limpa fotos órfãs (de produtos que mudaram de foto ou foram removidos) quando tudo está em dia
    try { const rm = chamarContingencia_('removerFotosOrfas', { ids: lista }); if (rm && rm.ok) res.removidas = rm.removidas || 0; } catch (e) {}
  }
  return res;
}

/* Monta o mesmo "espelho" que a contingência sempre recebeu (formato idêntico ao antigo), agora lendo as abas SB_. */
function sbSincronizarContingencia_(rapido) {
  /* espelho INCREMENTAL. No modo rápido (a cada ~10 min) só relê e reenvia o que mudou desde o último envio
     (as marcas por aba vêm de sbUpsert_). A "reserva" (pedidos em andamento) é sempre refeita: lê só o final das abas de vendas.
     Sincronização manual e a diária das 3h continuam COMPLETAS (rede de segurança contra qualquer diferença). */
  const stamps = sbLerStamps_(), sigAnt = sbLerAssinaturasEspelho_();
  let sigPub = sbAssinatura_(SB_ABAS_ESPELHO_PUBLICO_, stamps), sigInt = sbAssinatura_(SB_ABAS_ESPELHO_INTERNO_, stamps);
  let mapaFotosRapido = null;
  if (rapido === true) { try { const lf0 = chamarContingencia_('listarFotos'); if (lf0 && lf0.ok) mapaFotosRapido = lf0.fotos || {}; } catch (e0) {} }
  // rápido sem conseguir listar as fotos da contingência: não reenvia o público (evitaria apagar os ids das fotos de reserva)
  const precisaPublico = rapido !== true ? true : (!!mapaFotosRapido && (!sigAnt.publico || sigAnt.publico !== (sigPub + '|' + sbHashMapa_(mapaFotosRapido))));
  const precisaInterno = rapido !== true || !sigAnt.interno || sigAnt.interno !== sigInt;
  const cat = precisaPublico ? sbLerAba_('SB_categorias') : [], prods = precisaPublico ? sbLerAba_('SB_produtos') : [], combos = precisaPublico ? sbLerAba_('SB_combos') : [];
  if (precisaPublico && !prods.length && !combos.length) return { ok: false, message: 'As abas SB_produtos/SB_combos estão vazias: a sincronização com o Supabase ainda não chegou aqui. Rode "Sincronizar agora" e tente de novo.' };
  let fotos = { mapa: {}, enviadas: 0, faltam: 0, falhas: [], totalFotos: 0 };
  try {
    if (rapido) { if (mapaFotosRapido) fotos.mapa = mapaFotosRapido; }   // espelho rápido (a cada ~10 min): só reaproveita as fotos que a contingência já tem
    else fotos = sbSincronizarFotosContingencia_(prods, combos, 20000);
  } catch (eF) { registrarLog('Falha ao copiar fotos para a contingência', '', eF.message); }
  const reserva = function (id) { return (id && fotos.mapa[id]) || ''; };
  const cfg = {}; if (precisaPublico) sbLerAba_('SB_sistema').forEach(function (r) { cfg[String(r.chave)] = r.valor; });
  const txt = function (k, pad) { const v = cfg[k]; return (v === undefined || v === null || v === '') ? pad : String(v); };
  const formas = (precisaPublico || precisaInterno ? sbLerAba_('SB_formas_pagamento') : []).map(function (f, i) {
    return { id: f.id, nome: f.nome, ativa: sbBool_(f.ativa), visivelCardapio: sbBool_(f.visivel_cardapio), taxaPct: sbNum_(f.taxa_percentual), taxaFixa: sbNum_(f.taxa_fixa),
             prazoDias: sbNum_(f.prazo_dias), permiteTroco: sbBool_(f.permite_troco), ordem: sbNum_(f.ordem) || (i + 1),
             acrescimoPct: sbNum_(f.acrescimo_percentual), acrescimoFixo: sbNum_(f.acrescimo_fixo) };
  }).sort(function (a, b) { return a.ordem - b.ordem; });
  const dados = {};
  if (precisaPublico) dados.publico = {
      categorias: cat.map(function (c) { return { id: c.id, nome: c.nome, ativa: sbBool_(c.ativa), ordem: sbNum_(c.ordem) }; }).sort(function (a, b) { return a.ordem - b.ordem; }),
      produtos: prods.map(function (p) { return { id: p.id, nome: p.nome, descricao: p.descricao || '', categoria: p.categoria_id || '', ativo: sbBool_(p.ativo), fotoUrl: sbUrlFoto_(p.foto_id_principal), fotoReservaId: reserva(p.foto_id_principal), destaque: sbBool_(p.destaque), ordemCardapio: sbNum_(p.ordem_cardapio) }; }),
      produtoPrecos: sbLerAba_('SB_produto_precos').map(function (x) { return { produtoId: x.produto_id, formaPagamentoId: x.forma_pagamento_id, preco: sbNum_(x.preco) }; }),
      combos: combos.map(function (c) { return { id: c.id, nome: c.nome, categoria: c.categoria_id || '', ativo: sbBool_(c.ativo), fotoUrl: sbUrlFoto_(c.foto_id_principal), fotoReservaId: reserva(c.foto_id_principal), destaque: sbBool_(c.destaque), ordemCardapio: sbNum_(c.ordem_cardapio) }; }),
      comboPrecos: sbLerAba_('SB_combo_precos').map(function (x) { return { comboId: x.combo_id, formaPagamentoId: x.forma_pagamento_id, preco: sbNum_(x.preco) }; }),
      adicionais: sbLerAba_('SB_adicionais').map(function (a) { return { id: a.id, nome: a.nome, preco: sbNum_(a.preco), ativo: sbBool_(a.ativo) }; }),
      produtoAdicionais: sbLerAba_('SB_produto_adicionais').map(function (x) { return { id: x.id, produtoId: x.produto_id, adicionalId: x.adicional_id }; }),
      comboItens: sbLerAba_('SB_combo_itens').map(function (x) { return { comboId: x.combo_id, produtoId: x.produto_id }; }),
      formasPagamento: formas.map(function (f) { return { id: f.id, nome: f.nome, ativa: f.ativa, visivelCardapio: f.visivelCardapio, permiteTroco: f.permiteTroco, ordem: f.ordem, acrescimoPct: f.acrescimoPct, acrescimoFixo: f.acrescimoFixo }; }),
      configCardapio: { kicker: txt('CardapioKicker', 'DELIVERY · SABOR QUE CONQUISTA'), frase: txt('CardapioFrase', 'Peça pelo cardápio — rápido, sem complicação.'),
        tempoEntrega: txt('CardapioTempoEntrega', '40-60 min'), tempoRetirada: txt('CardapioTempoRetirada', '20-30 min'), tempoMesa: txt('CardapioTempoMesa', '20-30 min'),
        taxaEntrega: sbNum_(cfg['TaxaEntregaPadrao']),
        fechamento: { manual: sbJson_(cfg['CardapioFechadoManual'], null), periodos: sbJson_(cfg['CardapioPeriodosFechado'], []) },
        restaurante: { nome: txt('RestauranteNome', ''), endereco: txt('RestauranteEndereco', ''), telefone: txt('RestauranteTelefone', ''), horario: txt('RestauranteHorario', ''), redes: txt('RestauranteRedes', '') } }
  };
  if (precisaInterno) dados.interno = {
      clientes: sbLerAba_('SB_clientes').map(function (c) { return { id: c.id, nome: c.nome, telefone: c.telefone }; }),
      formasPagamentoCompleto: formas
  };
  // Reserva de leitura: pedidos em andamento (sem telefone, endereço nem pagamento)
  // OTIMIZAÇÃO: no modo rápido, só relê as abas de vendas se algo mudou nelas desde o último envio (ou se passaram 25 min, para o espelho não parecer parado).
  const sigRes = sbAssinatura_(['SB_vendas', 'SB_itens_venda'], stamps);
  const reservaParada = rapido === true && sigAnt.reserva === sigRes && (Date.now() - (Number(sigAnt.reservaEm) || 0)) < 25 * 60000;
  if (!reservaParada) try {
    const ATIVOS = { 'Recebido': 1, 'Em preparo': 1, 'Pronta': 1, 'Saiu para entrega': 1 };
    const vs = sbLerAbaUltimas_('SB_vendas', 500).filter(function (v) { return v.status === 'Confirmada' && ATIVOS[v.status_pedido]; });
    const idv = {}; vs.forEach(function (v) { idv[String(v.id)] = true; });
    const porVenda = {};
    sbLerAbaUltimas_('SB_itens_venda', 4000).forEach(function (i) { if (idv[String(i.venda_id)]) (porVenda[String(i.venda_id)] = porVenda[String(i.venda_id)] || []).push({ descricao: String(i.descricao || ''), quantidade: sbNum_(i.quantidade) }); });
    dados.reserva = { geradoEm: new Date().toISOString(), pedidos: vs.map(function (v) {
      return { numero: sbNum_(v.numero_pedido), em: (v.data_hora instanceof Date) ? v.data_hora.toISOString() : String(v.data_hora || ''), cliente: String(v.cliente_nome || ''), tipo: String(v.tipo || ''),
               statusPedido: String(v.status_pedido || ''), obs: String(v.observacoes_entrega || ''), itens: porVenda[String(v.id)] || [], total: sbNum_(v.valor_total) };
    }).sort(function (a, b) { return a.numero - b.numero; }).slice(-60) };
  } catch (eR) { registrarLog('Falha ao montar a reserva de leitura', '', eR.message); }
  // Cada chave do espelho vive numa célula (limite de 50 mil caracteres): se a lista de clientes crescer demais, corta para não travar o espelho.
  let cortouClientes = false;
  while (dados.interno && JSON.stringify(dados.interno).length > 45000 && dados.interno.clientes.length > 50) { dados.interno.clientes = dados.interno.clientes.slice(0, Math.floor(dados.interno.clientes.length * 0.9)); cortouClientes = true; }
  try {
    if (!Object.keys(dados).length) return { ok: true, message: 'Nada para enviar agora.' };
    const r = chamarContingencia_('atualizarEspelho', { dados: dados });
    if (r && r.ok) {   // guarda "o que a contingência já tem" para o próximo envio rápido saltar o que não mudou
      const novaSig = { publico: sigAnt.publico || '', interno: sigAnt.interno || '' };
      if (dados.publico) novaSig.publico = sigPub + '|' + sbHashMapa_(fotos.mapa || {});
      if (dados.interno) novaSig.interno = sigInt;
      if (dados.reserva) { novaSig.reserva = sigRes; novaSig.reservaEm = Date.now(); } else { novaSig.reserva = sigAnt.reserva || ''; novaSig.reservaEm = sigAnt.reservaEm || 0; }
      sbGravarAssinaturasEspelho_(novaSig);
    }
    const nota = (rapido === true ? ' Modo rápido: enviado só o que mudou (' + Object.keys(dados).join(', ') + ').' : '') + ' Fotos: ' + fotos.enviadas + ' copiada(s) agora' + (fotos.faltam ? ', faltam ' + fotos.faltam + ' (sincronize de novo)' : '') + (fotos.falhas.length ? ', ' + fotos.falhas.length + ' com falha (veja o Log)' : '') + '.';
    if (r) r.message = ((r.message || '') + nota + (cortouClientes ? ' Atenção: a lista de clientes do espelho foi reduzida por tamanho.' : '')).trim();
    if (fotos.falhas.length) registrarLog('Fotos que não foram para a contingência', '', fotos.falhas.slice(0, 5).join(' | '));
    registrarLog('Contingência sincronizada (a partir do Supabase)', '', (r && r.message) || '');
    return r;
  } catch (e) {
    registrarLog('Falha ao sincronizar contingência', '', e.message);
    return { ok: false, message: 'Não foi possível falar com a API de contingência: ' + e.message };
  }
}
const SB_ABAS_ESPELHO_PUBLICO_ = ['SB_categorias', 'SB_produtos', 'SB_combos', 'SB_sistema', 'SB_formas_pagamento', 'SB_produto_precos', 'SB_combo_precos', 'SB_adicionais', 'SB_produto_adicionais', 'SB_combo_itens'];
const SB_ABAS_ESPELHO_INTERNO_ = ['SB_clientes', 'SB_formas_pagamento'];
function sbAssinatura_(abas, stamps) { return abas.map(function (a) { return String(stamps[a] || 0); }).join('.'); }
function sbHashMapa_(mapa) {
  const ks = Object.keys(mapa || {}).sort(), txt = ks.map(function (k) { return k + '=' + mapa[k]; }).join('|');
  return Utilities.computeDigest(Utilities.DigestAlgorithm.MD5, txt).map(function (b) { return ('0' + (b & 0xff).toString(16)).slice(-2); }).join('');
}
function sbLerAssinaturasEspelho_() { try { return JSON.parse(PropertiesService.getScriptProperties().getProperty('SB_ESPELHO_SIG') || '{}') || {}; } catch (e) { return {}; } }
function sbGravarAssinaturasEspelho_(o) { try { PropertiesService.getScriptProperties().setProperty('SB_ESPELHO_SIG', JSON.stringify(o)); } catch (e) {} }
/* Impede dois espelhos ao mesmo tempo (manual + automático) SEM usar a trava das gravações: o envio de vendas nunca espera o espelho. */
function sbSincronizarContingenciaGuardada_(rapido) {
  const cache = CacheService.getScriptCache();
  if (cache.get('sb_espelho_rodando')) return { ok: false, message: 'Já há uma sincronização do espelho em andamento. Aguarde alguns segundos.' };
  cache.put('sb_espelho_rodando', '1', 120);
  try { return sbSincronizarContingencia_(rapido); } finally { try { cache.remove('sb_espelho_rodando'); } catch (e) {} }
}

function sbChaveContingencia_() {
  try { return { ok: true, chave: chaveContingencia_('CONTINGENCIA_CHAVE_INTERNA') }; }
  catch (e) { return { ok: false, message: 'Contingência sem chave configurada.' }; }
}
function sbListarPendentesContingencia_() {
  try { const r = chamarContingencia_('listarPendentes'); return (r && r.ok) ? { ok: true, pendentes: r.pendentes || [] } : { ok: false, message: (r && r.message) || 'A contingência recusou a chamada.' }; }
  catch (e) { return { ok: false, message: 'Não foi possível falar com a contingência: ' + e.message }; }
}
function sbMarcarSincronizadoContingencia_(ids) {
  let n = 0; const falhas = [];
  (ids || []).slice(0, 100).forEach(function (id) {
    try { const r = chamarContingencia_('marcarSincronizado', { id: String(id) }); if (r && r.ok) n++; else falhas.push(String(id)); } catch (e) { falhas.push(String(id)); }
  });
  return { ok: true, marcadas: n, falhas: falhas };
}

/* Espaço do Google Drive desta conta (mesmo formato de antes), classificando as fotos pelas abas SB_. */
function sbObterArmazenamento_() {
  const arm = obterArmazenamentoDrive_();
  const cats = { 'Imagens de produtos': { qtd: 0, bytes: 0 }, 'Imagens de combos': { qtd: 0, bytes: 0 }, 'Outras imagens': { qtd: 0, bytes: 0 },
                 'Arquivos de backup': { qtd: 0, bytes: 0 }, 'Arquivos do sistema': { qtd: 1, bytes: 0 } };
  const fp = {}, fc = {};
  sbLerColuna_('SB_produtos', 'foto_id_principal').forEach(function (v) { if (v) fp[v] = true; });   // só a coluna da foto (antes lia a aba inteira)
  sbLerColuna_('SB_combos', 'foto_id_principal').forEach(function (v) { if (v) fc[v] = true; });
  const arquivos = [];
  const varrer = function (pasta, catFn, limite) {
    const it = pasta.getFiles(); let n = 0;
    while (it.hasNext() && n++ < limite) {
      const f = it.next(), c = catFn(f), b = f.getSize();
      cats[c].qtd++; cats[c].bytes += b;
      arquivos.push({ nome: f.getName(), categoria: c, tamanho: b, criadoEm: f.getDateCreated().toISOString() });
    }
  };
  try { varrer(obterPastaFotos_(), function (f) { return fp[f.getId()] ? 'Imagens de produtos' : fc[f.getId()] ? 'Imagens de combos' : 'Outras imagens'; }, 500); } catch (e) {}
  try { varrer(obterPastaBackups_(), function () { return 'Arquivos de backup'; }, 200); } catch (e) {}
  try { const ssf = DriveApp.getFileById(SpreadsheetApp.getActiveSpreadsheet().getId()); cats['Arquivos do sistema'].bytes = tamanhoAproximadoPlanilha_(ssf.getId()) || ssf.getSize();
        arquivos.push({ nome: ssf.getName() + ' (planilha principal)', categoria: 'Arquivos do sistema', tamanho: cats['Arquivos do sistema'].bytes, criadoEm: ssf.getDateCreated().toISOString() }); } catch (e) {}
  arquivos.sort(function (a, b) { return b.tamanho - a.tamanho; });
  return { ok: true, drive: arm, categorias: cats, arquivos: arquivos.slice(0, 30), totalArquivos: arquivos.length };
}


/* ============================================================================
   MESES ARQUIVADOS NOS RELATÓRIOS
   Devolve as vendas (com itens e pagamentos) de um mês que já saiu do Supabase e está nas abas Arquivo_*.
   Chamado pela Edge Function "planilha-admin" (acao arquivoVendas). Só leitura.
   ============================================================================ */
/* Leitura enxuta das abas Arquivo_*: lê só UMA coluna para achar as linhas que interessam e depois só essas linhas
   (em blocos). Antes lia a aba inteira, em todas as colunas, a cada mês pedido. O resultado é o mesmo de sbLerAba_ + filter. */
function sbAbaCab_(nome) {
  const sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(nome);
  if (!sh || sh.getLastRow() < 2 || sh.getLastColumn() < 2) return null;
  return { sh: sh, cab: sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(String), ultima: sh.getLastRow() };
}
function sbLinhasOnde_(a, col, pred) {
  const ci = a.cab.indexOf(col); if (ci < 0) return [];
  const vals = a.sh.getRange(2, ci + 1, a.ultima - 1, 1).getValues(), out = [];
  for (let i = 0; i < vals.length; i++) if (pred(vals[i][0])) out.push(i + 2);
  return out;
}
function sbLerLinhas_(a, linhas) {
  if (!linhas.length) return [];
  const blocos = []; let ini = linhas[0], fim = linhas[0];
  for (let k = 1; k < linhas.length; k++) { if (linhas[k] - fim <= 25) fim = linhas[k]; else { blocos.push([ini, fim]); ini = fim = linhas[k]; } }
  blocos.push([ini, fim]);
  const quer = {}; linhas.forEach(function (l) { quer[l] = true; });
  const out = [];
  blocos.forEach(function (b) {
    a.sh.getRange(b[0], 1, b[1] - b[0] + 1, a.cab.length).getValues().forEach(function (r, idx) {
      if (!quer[b[0] + idx]) return;
      const o = {}; for (let i = 1; i < a.cab.length; i++) if (a.cab[i]) o[a.cab[i]] = r[i];
      if (o.id !== undefined && String(o.id) !== '') out.push(o);
    });
  });
  return out;
}
function sbLerAbaOnde_(nome, col, pred) { const a = sbAbaCab_(nome); return a ? sbLerLinhas_(a, sbLinhasOnde_(a, col, pred)) : []; }

function sbLerColuna_(nome, col) {
  const a = sbAbaCab_(nome); if (!a) return [];
  const ci = a.cab.indexOf(col); if (ci < 0) return [];
  return a.sh.getRange(2, ci + 1, a.ultima - 1, 1).getValues().map(function (r) { return r[0]; });
}
function sbMs_(v) { return (v instanceof Date) ? v.getTime() : Date.parse(String(v)); }
/* OTIMIZAÇÃO — cache da leitura de um mês arquivado. A chave inclui a marca de alteração das abas Arquivo_*:
   se o Supabase arquivar mais linhas, a marca muda e o cache antigo deixa de valer sozinho (nada fica desatualizado).
   Só leitura: não mexe na gravação nem na trava. Resultado grande é dividido em partes; se não couber, simplesmente não guarda. */
function sbCacheArq_(chave, abas, calcular) {
  const st = sbLerStamps_(), k = 'arq|' + chave + '|' + abas.map(function (a) { return String(st[a] || 0); }).join('.');
  let cache = null; try { cache = CacheService.getScriptCache(); } catch (e) {}
  if (cache) {
    try {
      const n = Number(cache.get(k + '|n') || 0);
      if (n > 0) {
        const chaves = []; for (let i = 0; i < n; i++) chaves.push(k + '|' + i);
        const got = cache.getAll(chaves), partes = [];
        for (let i = 0; i < n; i++) { if (got[chaves[i]] == null) { partes.length = 0; break; } partes.push(got[chaves[i]]); }
        if (partes.length === n) return JSON.parse(partes.join(''));
      }
    } catch (e) { /* cache é só acelerador */ }
  }
  const r = calcular();
  if (cache && r && r.ok) {
    try {
      const txt = JSON.stringify(r), T = 30000, n = Math.ceil(txt.length / T);
      if (n > 0 && n <= 30) {
        const obj = {}; obj[k + '|n'] = String(n);
        for (let i = 0; i < n; i++) obj[k + '|' + i] = txt.slice(i * T, (i + 1) * T);
        cache.putAll(obj, 1800);
      }
    } catch (e) { /* sem cache: segue normal */ }
  }
  return r;
}
function sbLerArquivo_(mes) {
  if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(String(mes || ''))) return { ok: false, message: 'Mês inválido.' };
  return sbCacheArq_('v|' + mes, ['Arquivo_Vendas', 'Arquivo_Itens', 'Arquivo_Pagamentos'], function () { return sbLerArquivoCalc_(mes); });
}
function sbLerArquivoCalc_(mes) {
  if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(String(mes || ''))) return { ok: false, message: 'Mês inválido.' };
  const a = String(mes).split('-'), ini = new Date(Number(a[0]), Number(a[1]) - 1, 1).getTime(), fim = new Date(Number(a[0]), Number(a[1]), 1).getTime();
  const pick = function (o, cols) { const r = {}; cols.forEach(function (c) { r[c] = (o[c] instanceof Date) ? o[c].toISOString() : o[c]; }); return r; };
  const colsV = ['id','numero_pedido','data_hora','cliente_nome','telefone_cliente','forma_pagamento','valor_total','custo_total','status','motivo_cancelamento','tipo','status_pedido','endereco','complemento','referencia','observacoes_entrega','pronta_em','concluida_em','status_pagamento','recebido_em','valor_original','valor_desconto','desconto_detalhe','entregador_id','saiu_em','origem','mesa_id','taxa_entrega','fechamento_entrega_id','registrado_por','inicio_preparo_em'];
  const vendas = sbLerAbaOnde_('Arquivo_Vendas', 'data_hora', function (x) { const t = sbMs_(x); return t >= ini && t < fim; });
  const ids = {}; vendas.forEach(function (v) { ids[String(v.id)] = true; });
  const itens = sbLerAbaOnde_('Arquivo_Itens', 'venda_id', function (x) { return ids[String(x)]; })
    .map(function (i) { return pick(i, ['id','venda_id','produto_id','combo_id','descricao','quantidade','valor_unitario','custo_unitario','valor_total_item','adicionais_ids']); });
  const pagamentos = sbLerAbaOnde_('Arquivo_Pagamentos', 'venda_id', function (x) { return ids[String(x)]; })
    .map(function (x) { return pick(x, ['id','venda_id','forma_pagamento','valor','taxa_aplicada']); });
  return { ok: true, mes: mes, vendas: vendas.map(function (v) { return pick(v, colsV); }), itens: itens, pagamentos: pagamentos };
}


/* D17 (Fase 8) — caixas fechados e sangrias de um mês arquivado (Arquivo_Caixa / Arquivo_Sangrias). Só leitura.
   Chamado pela Edge Function "planilha-admin" (acao arquivoCaixa). */
function sbLerArquivoCaixa_(mes) {
  if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(String(mes || ''))) return { ok: false, message: 'Mês inválido.' };
  return sbCacheArq_('c|' + mes, ['Arquivo_Caixa', 'Arquivo_Sangrias'], function () { return sbLerArquivoCaixaCalc_(mes); });
}
function sbLerArquivoCaixaCalc_(mes) {
  if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(String(mes || ''))) return { ok: false, message: 'Mês inválido.' };
  const a = String(mes).split('-'), ini = new Date(Number(a[0]), Number(a[1]) - 1, 1).getTime(), fim = new Date(Number(a[0]), Number(a[1]), 1).getTime();
  const lim = function (o) { const r = {}; Object.keys(o).forEach(function (k) { r[k] = (o[k] instanceof Date) ? o[k].toISOString() : o[k]; }); return r; };
  const caixas = sbLerAbaOnde_('Arquivo_Caixa', 'abertura', function (x) { const t = sbMs_(x); return t >= ini && t < fim; }).map(lim);
  const sangrias = sbLerAbaOnde_('Arquivo_Sangrias', 'data_hora', function (x) { const t = sbMs_(x); return t >= ini && t < fim; }).map(lim);
  return { ok: true, mes: mes, caixas: caixas, sangrias: sangrias };
}


/* ============================================================================
   CÓPIA DO BACKUP DO SUPABASE NO GOOGLE DRIVE
   A Edge Function "criar-backup" envia cada backup (.json.gz) para cá logo depois de guardá-lo no Storage do Supabase.
   Pasta própria (não mistura com as cópias da planilha). Limpa só os AUTOMÁTICOS antigos; manuais e de segurança ficam.
   ============================================================================ */
function sbPastaBackupsSupabase_() {
  const nome = 'Churros de Propósito - Backups do Supabase';
  const it = DriveApp.getFoldersByName(nome);
  return it.hasNext() ? it.next() : DriveApp.createFolder(nome);
}
function sbGuardarBackup_(b) {
  const nome = String(b.nome || '');
  if (!/^backup-[0-9A-Za-z\-]+\.json\.gz$/.test(nome)) return { ok: false, message: 'Nome de arquivo inválido.' };
  if (!b.base64 || String(b.base64).length > 25 * 1024 * 1024) return { ok: false, message: 'Arquivo ausente ou grande demais.' };
  const pasta = sbPastaBackupsSupabase_();
  const ja = pasta.getFilesByName(nome);
  if (ja.hasNext()) return { ok: true, repetido: true };                 // reenvio não duplica
  const blob = Utilities.newBlob(Utilities.base64Decode(String(b.base64)), 'application/gzip', nome);
  const f = pasta.createFile(blob);
  let removidos = 0;
  const dias = Math.max(7, Number(b.retencaoDias) || 7), corte = Date.now() - dias * 86400000;
  const it = pasta.getFiles();
  while (it.hasNext()) {
    const x = it.next();
    if (/-auto\.json\.gz$/.test(x.getName()) && x.getDateCreated().getTime() < corte) { x.setTrashed(true); removidos++; }
  }
  return { ok: true, id: f.getId(), tamanho: f.getSize(), removidos: removidos };
}


/* Reserva de leitura: chave só de consulta para os aparelhos (todos os perfis). Gerada pela própria contingência. */
function sbChaveLeitura_(renovar) {
  const props = PropertiesService.getScriptProperties();
  let k = props.getProperty('CONTINGENCIA_CHAVE_LEITURA');
  if (!k || renovar) {
    const r = chamarContingencia_('gerarChaveLeitura');
    if (!r || !r.ok || !r.chave) return { ok: false, message: (r && r.message) || 'A contingência não gerou a chave de leitura (atualize e republique o script da contingência).' };
    k = r.chave; props.setProperty('CONTINGENCIA_CHAVE_LEITURA', k);
  }
  return { ok: true, chave: k };
}
/* Lê só as últimas N linhas de uma aba SB_ (as vendas recentes ficam no fim). */
function sbLerAbaUltimas_(nome, n) {
  const sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(nome);
  if (!sh || sh.getLastRow() < 2 || sh.getLastColumn() < 2) return [];
  const cab = sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(String);
  const ini = Math.max(2, sh.getLastRow() - n + 1);
  return sh.getRange(ini, 1, sh.getLastRow() - ini + 1, cab.length).getValues().map(function (r) {
    const o = {}; for (let i = 1; i < cab.length; i++) if (cab[i]) o[cab[i]] = r[i]; return o;
  }).filter(function (o) { return o.id !== undefined && String(o.id) !== ''; });
}


/* ============================================================================
   LIMPEZA DAS ABAS QUE NÃO SÃO MAIS USADAS (criada em 09/10/2026, ampliada em 11/10/2026)
   O app hoje fala com o Supabase. Esta planilha só precisa de:
     - SB_*        cópia automática do Supabase, só das tabelas da lista SB_TABELAS_ESPELHO_ (as outras SB_ saem)
     - Arquivo_*   vendas e caixas antigos enviados pelo app para liberar espaço
     - Log         registro de eventos da sincronização (ainda é usado)
     - Auditoria   registro de ações importantes
   Tudo que está na lista abaixo é do sistema antigo (Google Sheets puro) e não tem mais uso.

   COMO USAR (no editor do Apps Script, escolha a função na lista e toque em Executar):
     1) previaLimpezaAbas        só MOSTRA o que seria apagado (nada é alterado). Veja em Execuções/Registro.
     2) ocultarAbasAntigas       esconde as abas (reversível: botão direito nas abas > Mostrar). Use uns dias.
     3) limparAbasAntigas        faz uma CÓPIA da planilha no seu Drive e então APAGA as abas antigas
                                 e os acionadores (gatilhos) antigos. Só apaga se a cópia foi feita.
     removerAcionadoresAntigos   remove só os gatilhos antigos (já está dentro do passo 3).
   Nunca apaga as SB_ da lista, Arquivo_*, Log nem Auditoria.
   ============================================================================ */
const ABAS_ANTIGAS_LIMPEZA_ = [
  'Vendas', 'ItensVenda', 'PagamentosVenda', 'Clientes', 'Produtos', 'ProdutoPrecos', 'ProdutoAdicionais', 'ProdutoIngredientes',
  'Combos', 'ComboPrecos', 'ComboItens', 'Categorias', 'Adicionais', 'Formas de Pagamento', 'Promoções', 'Cupons', 'CuponsUsos',
  'Mesas', 'Caixa', 'Sangrias', 'Estoque', 'MovimentaçõesEstoque', 'Despesas', 'DespesasRecorrentes', 'AjustesPosVenda',
  'Ocorrências', 'Feedbacks', 'Indicações', 'Fidelidade', 'Eventos', 'EventosCustos', 'EventosRecebimentos',
  'FechamentosEntrega', 'EntregasFechadas', 'Configurações', 'Usuários', 'Backups', 'Requisicoes', 'ContingenciaReconciliada',
  'Sheet1', 'Página1', 'Planilha1'
];
const ACIONADORES_ANTIGOS_LIMPEZA_ = ['tarefaDespesasMensais', 'criarBackupDiario', 'sincronizarContingencia', 'reconciliarContingenciaAuto', 'sbSincronizarContingenciaAuto'];

function abaSbUsada_(nome) { return /^SB_/.test(nome) && SB_TABELAS_ESPELHO_.indexOf(nome.slice(3)) !== -1; }
function abaProtegidaLimpeza_(nome) { return abaSbUsada_(nome) || /^Arquivo_/.test(nome) || nome === 'Log' || nome === 'Auditoria'; }

function abasParaLimpar_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const todas = ss.getSheets().map(function (s) { return s.getName(); });
  return {
    apagar: todas.filter(function (n) { return (ABAS_ANTIGAS_LIMPEZA_.indexOf(n) !== -1 || /^SB_/.test(n)) && !abaProtegidaLimpeza_(n); }),
    mantidas: todas.filter(function (n) { return abaProtegidaLimpeza_(n); }),
    desconhecidas: todas.filter(function (n) { return ABAS_ANTIGAS_LIMPEZA_.indexOf(n) === -1 && !/^SB_/.test(n) && !abaProtegidaLimpeza_(n); })
  };
}

function previaLimpezaAbas() {
  const r = abasParaLimpar_();
  const texto = 'SERIAM APAGADAS (' + r.apagar.length + '): ' + (r.apagar.join(', ') || 'nenhuma') +
    '\nFICAM (' + r.mantidas.length + '): ' + (r.mantidas.join(', ') || 'nenhuma') +
    '\nNÃO RECONHECIDAS, ficam como estão (' + r.desconhecidas.length + '): ' + (r.desconhecidas.join(', ') || 'nenhuma') +
    '\nACIONADORES ANTIGOS ENCONTRADOS: ' + (acionadoresAntigosEncontrados_().join(', ') || 'nenhum');
  Logger.log(texto);
  return texto;
}

function ocultarAbasAntigas() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const r = abasParaLimpar_();
  const visiveisFicam = ss.getSheets().filter(function (s) { return r.apagar.indexOf(s.getName()) === -1 && !s.isSheetHidden(); }).length;
  if (!visiveisFicam) { Logger.log('Nada a ocultar: sobraria nenhuma aba visível.'); return 'Nada a ocultar.'; }
  r.apagar.forEach(function (n) { const s = ss.getSheetByName(n); if (s && !s.isSheetHidden()) s.hideSheet(); });
  const msg = 'Ocultadas ' + r.apagar.length + ' aba(s): ' + r.apagar.join(', ') + '. Para mostrar de novo: menu Exibir > Planilhas ocultas.';
  Logger.log(msg); return msg;
}

function acionadoresAntigosEncontrados_() {
  return ScriptApp.getProjectTriggers().map(function (t) { return t.getHandlerFunction(); })
    .filter(function (f) { return ACIONADORES_ANTIGOS_LIMPEZA_.indexOf(f) !== -1; });
}

function removerAcionadoresAntigos() {
  let n = 0;
  ScriptApp.getProjectTriggers().forEach(function (t) {
    if (ACIONADORES_ANTIGOS_LIMPEZA_.indexOf(t.getHandlerFunction()) !== -1) { ScriptApp.deleteTrigger(t); n++; }
  });
  const msg = n + ' acionador(es) antigo(s) removido(s).';
  Logger.log(msg); return msg;
}

function limparAbasAntigas() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const r = abasParaLimpar_();
  if (!r.apagar.length) { const m = 'Nenhuma aba antiga encontrada. ' + removerAcionadoresAntigos(); Logger.log(m); return m; }
  // 1) cópia de segurança no Drive; sem ela, nada é apagado
  let copia;
  try {
    const stamp = Utilities.formatDate(new Date(), 'America/Sao_Paulo', 'yyyy-MM-dd HH:mm');
    copia = ss.copy('COPIA antes de limpar abas antigas - ' + stamp);
  } catch (e) {
    const m = 'NADA FOI APAGADO: não consegui fazer a cópia de segurança (' + e.message + ').'; Logger.log(m); return m;
  }
  // 2) apaga (nunca deixa a planilha sem abas)
  const apagadas = [], falhas = [];
  r.apagar.forEach(function (n) {
    try {
      if (ss.getSheets().length <= 1) { falhas.push(n + ' (única aba restante)'); return; }
      const s = ss.getSheetByName(n); if (s) { ss.deleteSheet(s); apagadas.push(n); }
    } catch (e) { falhas.push(n + ' (' + e.message + ')'); }
  });
  // 3) gatilhos antigos
  const gat = removerAcionadoresAntigos();
  const msg = 'Cópia criada: "' + copia.getName() + '" (Drive). Apagadas ' + apagadas.length + ' aba(s): ' + apagadas.join(', ') +
    (falhas.length ? '. Não apagadas: ' + falhas.join('; ') : '') + '. ' + gat;
  Logger.log(msg); return msg;
}


/* ============================================================================
   ENTRADA DO APP DA WEB
   GET (?ping=1): só responde "estou no ar" (o Supabase usa a cada 2 min para a planilha não "dormir").
   POST: só as ações do Supabase (ACOES_SERVIDOR_SB_). O sistema antigo (login, vendas pela planilha) foi retirado.
   ============================================================================ */
function doGet(e) {
  try { removerGatilhosAntigosUmaVez_(false); } catch (err) {}
  return responder({ ok: true, servico: 'Churros de Propósito - Planilha principal' });
}
function doPost(e) {
  let body;
  try { body = JSON.parse(e.postData.contents); } catch (err) { return responder({ ok: false, message: 'Requisição inválida.' }); }
  if (!body || typeof body !== 'object' || Array.isArray(body) || typeof body.action !== 'string') return responder({ ok: false, message: 'Requisição inválida.' });
  if (ACOES_SERVIDOR_SB_.indexOf(body.action) !== -1) return responder(acaoServidorSb_(body.action, body));
  return responder({ ok: false, message: 'Ação desconhecida: esta planilha só recebe chamadas do Supabase.' });
}

/* GATILHOS ANTIGOS: apaga os acionadores do sistema antigo (e o do espelho das 3h, que o Supabase já faz) UMA vez.
   Roda sozinho na primeira chamada depois de colar este código. Se algum gatilho antigo disparar antes disso,
   a função dele (abaixo) só chama esta limpeza: nada do sistema antigo roda. */
function removerGatilhosAntigosUmaVez_(forcar) {
  const props = PropertiesService.getScriptProperties();
  if (!forcar && props.getProperty('GATILHOS_ANTIGOS_LIMPOS') === 'v2') return;
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(5000)) return;
  try {
    if (!forcar && props.getProperty('GATILHOS_ANTIGOS_LIMPOS') === 'v2') return;
    const msg = removerAcionadoresAntigos();
    props.setProperty('GATILHOS_ANTIGOS_LIMPOS', 'v2');
    try { registrarLog('Gatilhos antigos removidos', '', msg); } catch (e) {}
  } finally { lock.releaseLock(); }
}
function tarefaDespesasMensais() { removerGatilhosAntigosUmaVez_(true); }
function criarBackupDiario() { removerGatilhosAntigosUmaVez_(true); }
function sincronizarContingencia() { removerGatilhosAntigosUmaVez_(true); }
function reconciliarContingenciaAuto() { removerGatilhosAntigosUmaVez_(true); }
function sbSincronizarContingenciaAuto() { removerGatilhosAntigosUmaVez_(true); }
